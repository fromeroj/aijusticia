import { Clock3, Download, Wallet } from 'lucide-react'
import { TIEMPO, caso, miembro } from '@/data/mock'
import { SectionLabel, fmtDinero, fmtFecha } from '@/components/bits'
import { cn } from '@/lib/utils'

const TARIFA = 4000

export function BillingPage() {
  const totalHoras = TIEMPO.reduce((s, r) => s + r.horas, 0)
  const facturables = TIEMPO.filter((r) => r.facturable)
  const totalFacturable = facturables.reduce((s, r) => s + r.horas * TARIFA, 0)

  return (
    <div className="h-full overflow-y-auto px-8 py-6">
      <div className="mx-auto max-w-4xl">
        <div className="flex items-end justify-between">
          <div>
            <h2 className="font-display text-[26px] font-semibold tracking-tight">Tiempo y honorarios</h2>
            <p className="mt-1 text-sm text-muted-foreground">Registro semanal del despacho · tarifa de referencia {fmtDinero(TARIFA)}/h</p>
          </div>
          <button className="flex items-center gap-1.5 rounded-md border border-border bg-card px-3 py-1.5 text-[13px] transition-colors hover:bg-accent">
            <Download className="size-4" /> Exportar para facturación
          </button>
        </div>

        <div className="mt-5 grid grid-cols-3 gap-4">
          <div className="rounded-lg border border-border bg-card p-4">
            <p className="flex items-center gap-2 font-mono2 text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
              <Clock3 className="size-3.5" /> Horas registradas
            </p>
            <p className="mt-2 font-display text-[24px] font-semibold">{totalHoras.toFixed(1)} h</p>
            <p className="mt-1 text-xs text-muted-foreground">últimos 7 días</p>
          </div>
          <div className="rounded-lg border border-border bg-card p-4">
            <p className="flex items-center gap-2 font-mono2 text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
              <Wallet className="size-3.5" /> Facturable
            </p>
            <p className="mt-2 font-display text-[24px] font-semibold">{fmtDinero(totalFacturable)}</p>
            <p className="mt-1 text-xs text-muted-foreground">{facturables.length} de {TIEMPO.length} registros</p>
          </div>
          <div className="rounded-lg border border-border bg-card p-4">
            <p className="font-mono2 text-[10px] uppercase tracking-[0.16em] text-muted-foreground">No facturable</p>
            <p className="mt-2 font-display text-[24px] font-semibold text-muted-foreground">
              {(totalHoras - facturables.reduce((s, r) => s + r.horas, 0)).toFixed(1)} h
            </p>
            <p className="mt-1 text-xs text-muted-foreground">gestión interna y memos</p>
          </div>
        </div>

        <div className="mt-6">
          <SectionLabel>Registros recientes</SectionLabel>
          <div className="mt-3 overflow-hidden rounded-lg border border-border bg-card">
            <table className="w-full text-left text-[13px]">
              <thead>
                <tr className="border-b border-border bg-muted/50 font-mono2 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                  <th className="px-4 py-2.5 font-medium">Fecha</th>
                  <th className="px-4 py-2.5 font-medium">Caso</th>
                  <th className="px-4 py-2.5 font-medium">Concepto</th>
                  <th className="px-4 py-2.5 font-medium">Miembro</th>
                  <th className="px-4 py-2.5 text-right font-medium">Horas</th>
                  <th className="px-4 py-2.5 text-right font-medium">Monto</th>
                  <th className="px-4 py-2.5 font-medium">Tipo</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {[...TIEMPO].sort((a, b) => b.fecha.localeCompare(a.fecha)).map((r) => (
                  <tr key={r.id} className="transition-colors hover:bg-accent/40">
                    <td className="px-4 py-3 font-mono2 text-[12px] text-muted-foreground">{fmtFecha(r.fecha)}</td>
                    <td className="px-4 py-3">
                      <p className="font-mono2 text-[11px] text-primary">{caso(r.casoId).folio}</p>
                    </td>
                    <td className="max-w-[280px] truncate px-4 py-3">{r.concepto}</td>
                    <td className="px-4 py-3 text-muted-foreground">{miembro(r.miembroId).nombre}</td>
                    <td className="px-4 py-3 text-right font-mono2 text-[12px]">{r.horas.toFixed(1)}</td>
                    <td className="px-4 py-3 text-right font-mono2 text-[12px]">
                      {r.facturable ? fmtDinero(r.horas * TARIFA) : '—'}
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={cn(
                          'rounded-full border px-2 py-0.5 text-[10px] font-medium',
                          r.facturable
                            ? 'border-[hsl(var(--sage)/0.3)] bg-[hsl(var(--sage)/0.08)] text-sage'
                            : 'border-border text-muted-foreground'
                        )}
                      >
                        {r.facturable ? 'facturable' : 'interno'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
