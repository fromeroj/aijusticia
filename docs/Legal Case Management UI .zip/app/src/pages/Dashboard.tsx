import { AlertTriangle, ArrowRight, CalendarClock, Clock3, FolderKanban, Wallet } from 'lucide-react'
import { Bar, BarChart, Cell, ResponsiveContainer, XAxis, YAxis } from 'recharts'
import { CASOS, FIRMA, MIEMBROS, PLAZOS, TIEMPO, caso } from '@/data/mock'
import { SectionLabel, diasHasta, fmtDinero, fmtFecha } from '@/components/bits'
import { cn } from '@/lib/utils'

const MATERIA_COLORS: Record<string, string> = {
  Mercantil: 'hsl(38 60% 42%)',
  Laboral: 'hsl(22 62% 32%)',
  Civil: 'hsl(145 22% 36%)',
  Amparo: 'hsl(199 60% 40%)',
  Familiar: 'hsl(280 35% 45%)',
  Fiscal: 'hsl(45 70% 40%)',
}

export function Dashboard({ goCaso, goAgenda }: { goCaso: (id: string) => void; goAgenda: () => void }) {
  const activos = CASOS.filter((c) => c.estado === 'Activo')
  const proximos = PLAZOS.filter((p) => diasHasta(p.fecha) >= 0 && diasHasta(p.fecha) <= 14).sort(
    (a, b) => a.fecha.localeCompare(b.fecha)
  )
  const horasMes = TIEMPO.reduce((s, r) => s + r.horas, 0)
  const porFacturar = TIEMPO.filter((r) => r.facturable).reduce((s, r) => s + r.horas * 4000, 0)

  const horasPorMateria = Object.entries(
    CASOS.reduce<Record<string, number>>((acc, c) => {
      acc[c.materia] = (acc[c.materia] ?? 0) + c.horas
      return acc
    }, {})
  ).map(([materia, horas]) => ({ materia, horas }))

  const cargaPorMiembro = MIEMBROS.map((m) => ({
    miembro: m,
    casos: activos.filter((c) => c.equipo.some((e) => e.miembroId === m.id)).length,
  })).filter((x) => x.casos > 0)
  const maxCarga = Math.max(...cargaPorMiembro.map((c) => c.casos))

  return (
    <div className="mx-auto max-w-6xl space-y-8 px-8 py-7">
      {/* encabezado editorial */}
      <div>
        <p className="font-mono2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
          Jueves 10 de septiembre de 2026 · {FIRMA.nombre}
        </p>
        <h2 className="mt-1 font-display text-[28px] font-semibold leading-tight tracking-tight">
          Buenos días, Max.
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Hay <span className="font-medium text-oxblood">2 términos fatales</span> en las próximas 72 horas y una
          solicitud de acceso esperando tu aprobación.
        </p>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-4 gap-4">
        <Kpi icon={<FolderKanban className="size-4" />} label="Casos activos" valor={String(activos.length)} pie="de 7 en el despacho" />
        <Kpi icon={<CalendarClock className="size-4" />} label="Plazos · 14 días" valor={String(proximos.length)} pie={`${proximos.filter((p) => p.fatal).length} fatales`} alerta />
        <Kpi icon={<Clock3 className="size-4" />} label="Horas del mes" valor={horasMes.toFixed(1)} pie="17.5 h facturables esta semana" />
        <Kpi icon={<Wallet className="size-4" />} label="Por facturar" valor={fmtDinero(porFacturar)} pie="septiembre" />
      </div>

      <div className="grid grid-cols-5 gap-6">
        {/* plazos próximos */}
        <div className="col-span-3">
          <div className="mb-3 flex items-center justify-between">
            <SectionLabel>Plazos próximos</SectionLabel>
            <button onClick={goAgenda} className="flex items-center gap-1 text-xs text-primary hover:underline">
              Ver agenda <ArrowRight className="size-3" />
            </button>
          </div>
          <div className="divide-y divide-border rounded-lg border border-border bg-card">
            {proximos.slice(0, 5).map((p) => {
              const d = diasHasta(p.fecha)
              const c = caso(p.casoId)
              return (
                <button
                  key={p.id}
                  onClick={() => goCaso(p.casoId)}
                  className="flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-accent/50"
                >
                  <div
                    className={cn(
                      'flex size-9 shrink-0 flex-col items-center justify-center rounded-md border',
                      p.fatal ? 'border-oxblood/30 bg-oxblood/5 text-oxblood' : 'border-border bg-muted text-muted-foreground'
                    )}
                  >
                    <span className="font-display text-[15px] font-semibold leading-none">{p.fecha.slice(8)}</span>
                    <span className="font-mono2 text-[8px] uppercase tracking-wider">{fmtFecha(p.fecha).split(' ')[1]}</span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13.5px] font-medium">{p.titulo}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {c.folio} · {c.nombre}
                    </p>
                  </div>
                  {p.fatal && (
                    <span className="flex items-center gap-1 rounded-full border border-oxblood/25 bg-oxblood/5 px-2 py-0.5 text-[10px] font-medium text-oxblood">
                      <AlertTriangle className="size-3" /> fatal
                    </span>
                  )}
                  <span className="font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">
                    {d === 0 ? 'hoy' : d === 1 ? 'mañana' : `${d} días`}
                  </span>
                </button>
              )
            })}
          </div>

          {/* horas por materia */}
          <div className="mt-6">
            <SectionLabel>Horas por materia · acumulado</SectionLabel>
            <div className="mt-3 rounded-lg border border-border bg-card p-4">
              <ResponsiveContainer width="100%" height={170}>
                <BarChart data={horasPorMateria} barSize={26}>
                  <XAxis
                    dataKey="materia"
                    tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis hide domain={[0, 'dataMax + 10']} />
                  <Bar dataKey="horas" radius={[3, 3, 0, 0]}>
                    {horasPorMateria.map((h) => (
                      <Cell key={h.materia} fill={MATERIA_COLORS[h.materia] ?? 'hsl(var(--primary))'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* columna derecha */}
        <div className="col-span-2 space-y-6">
          <div>
            <SectionLabel>Carga del equipo</SectionLabel>
            <div className="mt-3 space-y-3 rounded-lg border border-border bg-card p-4">
              {cargaPorMiembro.map(({ miembro: m, casos }) => (
                <div key={m.id} className="flex items-center gap-3">
                  <span className="w-28 truncate text-[13px]">{m.nombre}</span>
                  <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-primary transition-all"
                      style={{ width: `${(casos / maxCarga) * 100}%` }}
                    />
                  </div>
                  <span className="w-14 text-right font-mono2 text-[11px] text-muted-foreground">
                    {casos} {casos === 1 ? 'caso' : 'casos'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <SectionLabel>Actividad reciente</SectionLabel>
            <div className="mt-3 rounded-lg border border-border bg-card p-4">
              <ol className="relative space-y-4 border-l border-border pl-4">
                {ACTIVIDAD.map((a, i) => (
                  <li key={i} className="relative">
                    <span className="absolute -left-[21px] top-1 size-2 rounded-full border-2 border-card bg-primary" />
                    <p className="text-[13px] leading-snug">{a.texto}</p>
                    <p className="mt-0.5 font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">
                      {a.autor} · {a.fecha}
                    </p>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

const ACTIVIDAD = [
  { texto: 'Se admitieron las periciales en Alulia vs. Bento', autor: 'Max Iriarte', fecha: 'ayer 16:40' },
  { texto: 'Tomás confirmó agenda del fedatario núm. 42', autor: 'Tomás Villa', fecha: '8 sep' },
  { texto: 'Pari Cortázar subió el acta constitutiva v2', autor: 'Cliente', fecha: '4 sep' },
  { texto: 'Plantilla de arrendamiento actualizada a la reforma 2026', autor: 'Diego Salcedo', fecha: '1 sep' },
]

function Kpi({
  icon,
  label,
  valor,
  pie,
  alerta,
}: {
  icon: React.ReactNode
  label: string
  valor: string
  pie: string
  alerta?: boolean
}) {
  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <div className="flex items-center gap-2 text-muted-foreground">
        {icon}
        <span className="font-mono2 text-[10px] font-medium uppercase tracking-[0.16em]">{label}</span>
      </div>
      <p className={cn('mt-2 font-display text-[26px] font-semibold leading-none tracking-tight', alerta && 'text-oxblood')}>
        {valor}
      </p>
      <p className="mt-1.5 text-xs text-muted-foreground">{pie}</p>
    </div>
  )
}
