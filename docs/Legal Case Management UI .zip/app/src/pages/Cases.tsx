import { useMemo, useState } from 'react'
import {
  AlertTriangle,
  ArrowUpRight,
  Ban,
  Check,
  ChevronRight,
  Circle,
  Clock3,
  Download,
  Eye,
  FileText,
  FileImage,
  FileSpreadsheet,
  FolderKanban,
  GitBranch,
  Lock,
  MessageSquarePlus,
  ScrollText,
  Search,
  Share2,
  ShieldAlert,
  Sparkles,
  UserPlus,
} from 'lucide-react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { CASOS, MIEMBROS, PLANTILLAS, PLAZOS, TAREAS, cliente, miembro } from '@/data/mock'
import type { Caso, Documento, EventoTimeline } from '@/types'
import { Avatar, EstadoDot, MateriaBadge, SectionLabel, diasHasta, fmtDinero, fmtFecha } from '@/components/bits'
import { cn } from '@/lib/utils'

const TABS = ['Resumen', 'Documentos', 'Notas', 'Plazos y tareas', 'Timeline', 'Equipo'] as const
type Tab = (typeof TABS)[number]

export function CasesPage({ selectedId, onSelect }: { selectedId: string | null; onSelect: (id: string) => void }) {
  const [q, setQ] = useState('')
  const [filtro, setFiltro] = useState<'todos' | 'activos' | 'confidenciales' | 'compartidos'>('todos')
  const casoSel = CASOS.find((c) => c.id === selectedId) ?? null

  const lista = useMemo(() => {
    const t = q.toLowerCase()
    return CASOS.filter((c) => {
      if (filtro === 'activos' && c.estado !== 'Activo') return false
      if (filtro === 'confidenciales' && !c.confidencial) return false
      if (filtro === 'compartidos' && !c.compartido) return false
      return !t || c.nombre.toLowerCase().includes(t) || c.folio.toLowerCase().includes(t) || cliente(c.clienteId).nombre.toLowerCase().includes(t)
    })
  }, [q, filtro])

  return (
    <div className="flex h-full min-h-0">
      {/* lista de casos */}
      <div className="flex w-[300px] shrink-0 flex-col border-r border-border bg-card/40">
        <div className="space-y-2 border-b border-border p-3">
          <div className="flex items-center gap-2 rounded-md border border-input bg-background px-2.5">
            <Search className="size-3.5 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Buscar por nombre, folio o cliente…"
              className="h-8 flex-1 bg-transparent text-[13px] outline-none placeholder:text-muted-foreground"
            />
          </div>
          <div className="flex flex-wrap gap-1">
            {(['todos', 'activos', 'confidenciales', 'compartidos'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFiltro(f)}
                className={cn(
                  'rounded-full border px-2.5 py-1 font-mono2 text-[10px] uppercase tracking-wider transition-colors',
                  filtro === f
                    ? 'border-primary/40 bg-primary/10 text-primary'
                    : 'border-border text-muted-foreground hover:text-foreground'
                )}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {lista.map((c) => (
            <button
              key={c.id}
              onClick={() => onSelect(c.id)}
              className={cn(
                'w-full border-b border-border px-4 py-3 text-left transition-colors',
                selectedId === c.id ? 'bg-primary/[0.06]' : 'hover:bg-accent/50'
              )}
            >
              <div className="flex items-center gap-2">
                <span className="font-mono2 text-[10px] tracking-wider text-muted-foreground">{c.folio}</span>
                {c.confidencial && <Lock className="size-3 text-gold" />}
                {c.compartido && <Share2 className="size-3 text-sage" />}
                <span className="ml-auto">
                  <EstadoDot estado={c.estado} />
                </span>
              </div>
              <p className={cn('mt-1 text-[13.5px] leading-snug', selectedId === c.id ? 'font-semibold' : 'font-medium')}>
                {c.nombre}
              </p>
              <div className="mt-1.5 flex items-center gap-2">
                <MateriaBadge materia={c.materia} />
                <span className="truncate text-[11px] text-muted-foreground">{cliente(c.clienteId).nombre}</span>
              </div>
            </button>
          ))}
          {lista.length === 0 && (
            <p className="px-4 py-10 text-center text-sm text-muted-foreground">Ningún caso coincide con el filtro.</p>
          )}
        </div>
      </div>

      {/* detalle */}
      {casoSel ? (
        <CaseDetail caso={casoSel} />
      ) : (
        <div className="flex flex-1 items-center justify-center">
          <div className="text-center">
            <FolderKanban className="mx-auto size-8 text-muted-foreground/40" />
            <p className="mt-3 font-display text-lg">Selecciona un caso</p>
            <p className="mt-1 text-sm text-muted-foreground">El expediente completo vive dentro del caso.</p>
          </div>
        </div>
      )}
    </div>
  )
}

function CaseDetail({ caso: c }: { caso: Caso }) {
  const [tab, setTab] = useState<Tab>('Resumen')
  const cl = cliente(c.clienteId)

  return (
    <div className="flex min-w-0 flex-1 flex-col">
      {/* encabezado del caso */}
      <div className="border-b border-border px-6 py-4">
        <div className="flex items-center gap-2 font-mono2 text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
          {c.folio} · creado {fmtFecha(c.creado)}
          {c.confidencial && (
            <span className="flex items-center gap-1 rounded-full border border-gold/30 bg-gold/10 px-2 py-0.5 text-gold">
              <Lock className="size-2.5" /> confidencial
            </span>
          )}
          {c.compartido && (
            <span className="flex items-center gap-1 rounded-full border border-[hsl(var(--sage)/0.3)] bg-[hsl(var(--sage)/0.1)] px-2 py-0.5 text-sage">
              <Share2 className="size-2.5" /> {c.origen}
            </span>
          )}
        </div>
        <div className="mt-1.5 flex items-start justify-between gap-4">
          <h2 className="font-display text-[22px] font-semibold leading-tight tracking-tight">{c.nombre}</h2>
          <div className="flex shrink-0 items-center gap-2">
            <MateriaBadge materia={c.materia} />
            <EstadoDot estado={c.estado} />
          </div>
        </div>
        <p className="mt-1 text-[13px] text-muted-foreground">
          {cl.nombre}
          {c.contraparte && <span> vs. {c.contraparte}</span>} · {c.jurisdiccion}
          {c.juzgado && <span> · {c.juzgado}</span>}
          {c.expedienteJudicial && <span className="font-mono2"> · exp. {c.expedienteJudicial}</span>}
        </p>

        {/* tabs */}
        <div className="mt-3 flex gap-1">
          {TABS.map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cn(
                'rounded-md px-3 py-1.5 text-[13px] transition-colors',
                tab === t ? 'bg-primary/10 font-medium text-primary' : 'text-muted-foreground hover:bg-accent hover:text-foreground'
              )}
            >
              {t}
              {t === 'Documentos' && c.documentos.length > 0 && (
                <span className="ml-1.5 font-mono2 text-[10px] text-muted-foreground">{c.documentos.length}</span>
              )}
              {t === 'Notas' && c.notas.length > 0 && (
                <span className="ml-1.5 font-mono2 text-[10px] text-muted-foreground">{c.notas.length}</span>
              )}
            </button>
          ))}
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto px-6 py-5">
        {tab === 'Resumen' && <TabResumen caso={c} />}
        {tab === 'Documentos' && <TabDocumentos caso={c} />}
        {tab === 'Notas' && <TabNotas caso={c} />}
        {tab === 'Plazos y tareas' && <TabPlazos caso={c} />}
        {tab === 'Timeline' && <TabTimeline caso={c} />}
        {tab === 'Equipo' && <TabEquipo caso={c} />}
      </div>
    </div>
  )
}

/* ---------- Resumen ---------- */

function TabResumen({ caso: c }: { caso: Caso }) {
  const [genOpen, setGenOpen] = useState(false)
  return (
    <div className="grid max-w-4xl grid-cols-3 gap-6">
      <div className="col-span-2 space-y-5">
        <div>
          <SectionLabel>Situación actual</SectionLabel>
          <p className="mt-2 text-[14px] leading-relaxed">{c.descripcion}</p>
        </div>
        <div>
          <SectionLabel>Etapa procesal</SectionLabel>
          <p className="mt-2 font-display text-lg font-medium tracking-tight">{c.etapa}</p>
        </div>
        <button
          onClick={() => setGenOpen(true)}
          className="flex items-center gap-2 rounded-md border border-primary/30 bg-primary/5 px-3.5 py-2 text-[13px] font-medium text-primary transition-colors hover:bg-primary/10"
        >
          <ScrollText className="size-4" /> Generar documento desde plantilla
          <ArrowUpRight className="size-3.5" />
        </button>
      </div>
      <div className="space-y-4">
        <MetaCard
          titulo="Del caso"
          filas={[
            ['Cliente', cliente(c.clienteId).nombre],
            ['Contraparte', c.contraparte ?? '—'],
            ['Jurisdicción', c.jurisdiccion],
            ['Juzgado', c.juzgado ?? '—'],
            ['Expediente', c.expedienteJudicial ?? '—'],
          ]}
        />
        <MetaCard
          titulo="Economía"
          filas={[
            ['Horas registradas', `${c.horas} h`],
            ['Honorarios', fmtDinero(c.honorarios)],
            ['Última actividad', fmtFecha(c.actualizado)],
          ]}
        />
      </div>
      <GenerarDialog open={genOpen} onClose={() => setGenOpen(false)} caso={c} />
    </div>
  )
}

function MetaCard({ titulo, filas }: { titulo: string; filas: [string, string][] }) {
  return (
    <div className="rounded-lg border border-border bg-card p-4">
      <SectionLabel>{titulo}</SectionLabel>
      <dl className="mt-2.5 space-y-2">
        {filas.map(([k, v]) => (
          <div key={k} className="flex justify-between gap-3 text-[13px]">
            <dt className="shrink-0 text-muted-foreground">{k}</dt>
            <dd className="truncate text-right font-medium">{v}</dd>
          </div>
        ))}
      </dl>
    </div>
  )
}

/* ---------- Documentos ---------- */

function DocIcon({ tipo }: { tipo: Documento['tipo'] }) {
  const cls = 'size-4'
  if (tipo === 'img') return <FileImage className={cls} />
  if (tipo === 'xlsx') return <FileSpreadsheet className={cls} />
  return <FileText className={cls} />
}

function TabDocumentos({ caso: c }: { caso: Caso }) {
  const [preview, setPreview] = useState<Documento | null>(null)
  const [promovido, setPromovido] = useState<string | null>(null)

  if (c.documentos.length === 0)
    return <Vacia icon={<FileText className="size-7" />} texto="Sin documentos aún. Los archivos que suba el cliente aparecerán aquí con su versión y estado de OCR." />

  return (
    <div className="max-w-4xl">
      <div className="divide-y divide-border rounded-lg border border-border bg-card">
        {c.documentos.map((d) => (
          <div key={d.id} className="flex items-center gap-3 px-4 py-3">
            <span className="flex size-9 items-center justify-center rounded-md bg-muted text-muted-foreground">
              <DocIcon tipo={d.tipo} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[13.5px] font-medium">{d.nombre}</p>
              <p className="font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">
                {d.tamano} · {d.metodo} · {fmtFecha(d.fecha)} · {d.autor}
              </p>
            </div>
            <span className="rounded-full border border-border bg-muted px-2 py-0.5 font-mono2 text-[10px] text-muted-foreground">
              v{d.version}
            </span>
            <div className="flex items-center gap-1">
              <IconBtn title="Vista previa" onClick={() => setPreview(d)}>
                <Eye className="size-4" />
              </IconBtn>
              <IconBtn title="Descargar">
                <Download className="size-4" />
              </IconBtn>
              {d.tipo === 'docx' && (
                <button
                  onClick={() => setPromovido(d.id)}
                  className="ml-1 rounded-md border border-border px-2 py-1 font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary"
                  title="Promover a plantilla del despacho (PII-scan)"
                >
                  → plantilla
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {promovido && (
        <div className="mt-3 flex items-center gap-2 rounded-md border border-[hsl(var(--sage)/0.3)] bg-[hsl(var(--sage)/0.08)] px-4 py-2.5 text-[13px] text-sage">
          <Check className="size-4" />
          Plantilla creada: {c.documentos.find((d) => d.id === promovido)?.nombre.replace('.docx', '_anon.docx')} · PII-scan completado (1 dato anonimizado)
        </div>
      )}

      <Dialog open={!!preview} onOpenChange={(v) => !v && setPreview(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="font-display">{preview?.nombre}</DialogTitle>
          </DialogHeader>
          {preview?.contenido ? (
            <div className="max-h-[55vh] overflow-y-auto rounded-md border border-border bg-background p-5">
              {preview.contenido.map((linea, i) => (
                <p key={i} className={cn('text-[13px] leading-relaxed', i === 0 && 'font-display text-base font-semibold', linea === '' && 'h-3')}>
                  {linea}
                </p>
              ))}
            </div>
          ) : (
            <div className="flex h-48 flex-col items-center justify-center rounded-md border border-dashed border-border text-muted-foreground">
              <Eye className="size-6" />
              <p className="mt-2 text-sm">Vista previa no disponible para este formato.</p>
              <p className="text-xs">El texto extraído por OCR está indexado para Izel y la búsqueda global.</p>
            </div>
          )}
          <p className="font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">
            {preview?.versiones} {preview?.versiones === 1 ? 'versión' : 'versiones'} · método: {preview?.metodo}
          </p>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function IconBtn({ children, title, onClick }: { children: React.ReactNode; title: string; onClick?: () => void }) {
  return (
    <button
      title={title}
      onClick={onClick}
      className="flex size-8 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
    >
      {children}
    </button>
  )
}

/* ---------- Notas ---------- */

function TabNotas({ caso: c }: { caso: Caso }) {
  const [notas, setNotas] = useState(c.notas)
  const [texto, setTexto] = useState('')

  return (
    <div className="max-w-3xl space-y-5">
      <div className="rounded-lg border border-border bg-card p-4">
        <SectionLabel>Nueva nota — visible para todos los participantes del caso</SectionLabel>
        <textarea
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          rows={3}
          placeholder="Escribir una nota del caso…"
          className="mt-2 w-full resize-none rounded-md border border-input bg-background px-3 py-2 text-[13.5px] outline-none placeholder:text-muted-foreground focus:border-primary/50"
        />
        <div className="mt-2 flex justify-end">
          <button
            onClick={() => {
              if (!texto.trim()) return
              setNotas([{ id: 'nx' + Date.now(), autor: 'Max Iriarte', fecha: '2026-09-10 12:00', texto: texto.trim() }, ...notas])
              setTexto('')
            }}
            className="flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-[13px] font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            <MessageSquarePlus className="size-3.5" /> Agregar nota
          </button>
        </div>
      </div>

      <ol className="space-y-4">
        {notas.map((n) => {
          const m = MIEMBROS.find((x) => x.nombre === n.autor)
          return (
            <li key={n.id} className="flex gap-3">
              <Avatar iniciales={m?.iniciales ?? n.autor.slice(0, 2).toUpperCase()} className="mt-0.5" />
              <div className="min-w-0 flex-1">
                <p className="flex items-baseline gap-2">
                  <span className="text-[13.5px] font-semibold">{n.autor}</span>
                  <span className="font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">{n.fecha}</span>
                </p>
                <p className="mt-1 text-[13.5px] leading-relaxed text-foreground/90">{n.texto}</p>
              </div>
            </li>
          )
        })}
        {notas.length === 0 && <p className="py-6 text-center text-sm text-muted-foreground">Sin notas todavía.</p>}
      </ol>
    </div>
  )
}

/* ---------- Plazos y tareas ---------- */

function TabPlazos({ caso: c }: { caso: Caso }) {
  const plazos = PLAZOS.filter((p) => p.casoId === c.id).sort((a, b) => a.fecha.localeCompare(b.fecha))
  const [tareas, setTareas] = useState(TAREAS.filter((t) => t.casoId === c.id))

  return (
    <div className="grid max-w-4xl grid-cols-2 gap-6">
      <div>
        <SectionLabel>Plazos y audiencias</SectionLabel>
        <div className="mt-3 space-y-2">
          {plazos.map((p) => {
            const d = diasHasta(p.fecha)
            return (
              <div key={p.id} className="flex items-center gap-3 rounded-lg border border-border bg-card px-4 py-3">
                <div className={cn('flex size-9 shrink-0 flex-col items-center justify-center rounded-md border', p.fatal ? 'border-oxblood/30 bg-oxblood/5 text-oxblood' : 'border-border bg-muted text-muted-foreground')}>
                  <span className="font-display text-[15px] font-semibold leading-none">{p.fecha.slice(8)}</span>
                  <span className="font-mono2 text-[8px] uppercase">{fmtFecha(p.fecha).split(' ')[1]}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[13px] font-medium leading-snug">{p.titulo}</p>
                  <p className="font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">
                    {p.tipo} · {d === 0 ? 'hoy' : d === 1 ? 'mañana' : `en ${d} días`}
                  </p>
                </div>
                {p.fatal && <AlertTriangle className="size-4 shrink-0 text-oxblood" />}
              </div>
            )
          })}
          {plazos.length === 0 && <p className="py-6 text-center text-sm text-muted-foreground">Sin plazos registrados.</p>}
        </div>
      </div>
      <div>
        <SectionLabel>Tareas</SectionLabel>
        <div className="mt-3 space-y-2">
          {tareas.map((t) => (
            <button
              key={t.id}
              onClick={() => setTareas(tareas.map((x) => (x.id === t.id ? { ...x, hecha: !x.hecha } : x)))}
              className="flex w-full items-center gap-3 rounded-lg border border-border bg-card px-4 py-3 text-left transition-colors hover:bg-accent/40"
            >
              <span className={cn('flex size-[18px] shrink-0 items-center justify-center rounded-full border', t.hecha ? 'border-sage bg-sage text-white' : 'border-muted-foreground/40')}>
                {t.hecha && <Check className="size-3" />}
              </span>
              <span className={cn('min-w-0 flex-1 text-[13px] leading-snug', t.hecha && 'text-muted-foreground line-through')}>
                {t.titulo}
              </span>
              <span className="shrink-0 font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">
                {miembro(t.asignado).iniciales} · {fmtFecha(t.vence)}
              </span>
            </button>
          ))}
          {tareas.length === 0 && <p className="py-6 text-center text-sm text-muted-foreground">Sin tareas asignadas.</p>}
        </div>
      </div>
    </div>
  )
}

/* ---------- Timeline ---------- */

const TIMELINE_ICON: Record<EventoTimeline['tipo'], any> = {
  creacion: FolderKanban,
  documento: FileText,
  nota: MessageSquarePlus,
  acceso: Share2,
  asignacion: UserPlus,
  plazo: Clock3,
  tarea: Check,
  version: GitBranch,
}

function TabTimeline({ caso: c }: { caso: Caso }) {
  const eventos = [...c.timeline].sort((a, b) => b.fecha.localeCompare(a.fecha))
  return (
    <div className="max-w-2xl">
      <ol className="relative space-y-5 border-l border-border pl-6">
        {eventos.map((e) => {
          const Icon = TIMELINE_ICON[e.tipo] ?? Circle
          return (
            <li key={e.id} className="relative">
              <span className="absolute -left-[31px] flex size-5 items-center justify-center rounded-full border border-border bg-card text-muted-foreground">
                <Icon className="size-3" />
              </span>
              <p className="text-[13.5px] leading-snug">{e.texto}</p>
              <p className="mt-0.5 font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">
                {e.autor && `${e.autor} · `}
                {fmtFecha(e.fecha)}
              </p>
            </li>
          )
        })}
      </ol>
      <p className="mt-6 flex items-center gap-2 font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">
        <ShieldAlert className="size-3.5" /> Bitácora de auditoría — cada vista, descarga y acceso queda registrada
      </p>
    </div>
  )
}

/* ---------- Equipo ---------- */

function TabEquipo({ caso: c }: { caso: Caso }) {
  const disponibles = MIEMBROS.filter((m) => !c.equipo.some((e) => e.miembroId === m.id) && !c.vetos.some((v) => v.miembroId === m.id))
  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <SectionLabel>Asignaciones</SectionLabel>
        <div className="mt-3 divide-y divide-border rounded-lg border border-border bg-card">
          {c.equipo.map((a) => {
            const m = miembro(a.miembroId)
            return (
              <div key={a.miembroId} className="flex items-center gap-3 px-4 py-3">
                <Avatar iniciales={m.iniciales} />
                <div className="flex-1">
                  <p className="text-[13.5px] font-medium">{m.nombre}</p>
                  <p className="font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">{m.rol} en la firma</p>
                </div>
                <span className="rounded-full border border-primary/30 bg-primary/5 px-2.5 py-0.5 text-[11px] font-medium text-primary">
                  {a.rol} del caso
                </span>
                <button className="text-xs text-muted-foreground hover:text-oxblood">Quitar</button>
              </div>
            )
          })}
        </div>
        {disponibles.length > 0 && (
          <button className="mt-2 flex items-center gap-1.5 rounded-md border border-border px-3 py-1.5 text-[13px] text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary">
            <UserPlus className="size-3.5" /> Asignar miembro ({disponibles.map((m) => m.nombre.split(' ')[0]).join(', ')})
          </button>
        )}
      </div>

      <div>
        <SectionLabel>Muro ético — vetos activos</SectionLabel>
        {c.vetos.length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">Sin vetos. Todos los miembros pueden ser asignados a este caso.</p>
        ) : (
          <div className="mt-3 space-y-2">
            {c.vetos.map((v) => {
              const m = miembro(v.miembroId)
              return (
                <div key={v.miembroId} className="flex items-center gap-3 rounded-lg border border-oxblood/25 bg-oxblood/5 px-4 py-3">
                  <Ban className="size-4 text-oxblood" />
                  <div className="flex-1">
                    <p className="text-[13.5px] font-medium">{m.nombre} — vetado</p>
                    <p className="text-xs text-muted-foreground">
                      {v.razon} · desde {fmtFecha(v.fecha)}. No ve el caso ni aparece como asignable.
                    </p>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      <div className="flex items-center gap-3 rounded-lg border border-border bg-card px-4 py-3">
        <Lock className={cn('size-4', c.confidencial ? 'text-gold' : 'text-muted-foreground')} />
        <p className="flex-1 text-[13px]">
          {c.confidencial
            ? 'Caso confidencial: solo los miembros asignados pueden verlo, incluidos los admins.'
            : 'Caso visible para toda la firma. Puedes marcarlo como confidencial.'}
        </p>
        <ChevronRight className="size-4 text-muted-foreground" />
      </div>
    </div>
  )
}

/* ---------- Generar desde plantilla ---------- */

function GenerarDialog({ open, onClose, caso: c }: { open: boolean; onClose: () => void; caso: Caso }) {
  const plantillas = PLANTILLAS.filter((p) => p.materia === c.materia || (p.materia as string) === 'General')
  const [plantillaId, setPlantillaId] = useState<string>('')
  const [estado, setEstado] = useState<'form' | 'job' | 'done'>('form')
  const plantilla = PLANTILLAS.find((p) => p.id === plantillaId)

  const generar = () => {
    setEstado('job')
    setTimeout(() => setEstado('done'), 1600)
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) {
          onClose()
          setEstado('form')
          setPlantillaId('')
        }
      }}
    >
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display">Generar documento — {c.folio}</DialogTitle>
        </DialogHeader>

        {estado === 'form' && (
          <div className="space-y-4">
            <div>
              <SectionLabel>Plantilla ({c.materia} + generales)</SectionLabel>
              <div className="mt-2 space-y-1.5">
                {plantillas.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setPlantillaId(p.id)}
                    className={cn(
                      'w-full rounded-md border px-3 py-2.5 text-left transition-colors',
                      plantillaId === p.id ? 'border-primary/50 bg-primary/5' : 'border-border hover:border-primary/30'
                    )}
                  >
                    <p className="text-[13.5px] font-medium">{p.nombre}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      v{p.version} · {p.usos} usos · {p.variables.length} variables · PII-scan: {p.piiScan}
                    </p>
                  </button>
                ))}
              </div>
            </div>
            {plantilla && (
              <div>
                <SectionLabel>Variables detectadas</SectionLabel>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  {plantilla.variables.map((v) => (
                    <input
                      key={v}
                      placeholder={v}
                      className="h-8 rounded-md border border-input bg-background px-2.5 font-mono2 text-[12px] outline-none placeholder:text-muted-foreground focus:border-primary/50"
                    />
                  ))}
                </div>
              </div>
            )}
            <button
              disabled={!plantilla}
              onClick={generar}
              className="w-full rounded-md bg-primary py-2 text-[13.5px] font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-40"
            >
              Generar en el caso
            </button>
          </div>
        )}

        {estado === 'job' && (
          <div className="flex flex-col items-center py-10">
            <Sparkles className="size-6 animate-pulse text-primary" />
            <p className="mt-3 text-sm">Generando documento en Nextcloud…</p>
            <p className="mt-1 font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">job #4821 · sondeando</p>
          </div>
        )}

        {estado === 'done' && plantilla && (
          <div className="py-4 text-center">
            <Check className="mx-auto size-6 text-sage" />
            <p className="mt-3 font-display text-lg font-medium">Documento listo</p>
            <p className="mt-1 font-mono2 text-[12px] text-muted-foreground">
              {plantilla.nombre.toLowerCase().replace(/[^a-záéíóúñ]+/gi, '_')}_{c.folio.toLowerCase()}.docx
            </p>
            <p className="mt-2 text-xs text-muted-foreground">Guardado en la bóveda del caso · PII: sin datos sensibles en variables</p>
            <div className="mt-4 flex justify-center gap-2">
              <button className="rounded-md border border-border px-3 py-1.5 text-[13px] hover:bg-accent">Abrir en Nextcloud</button>
              <button onClick={onClose} className="rounded-md bg-primary px-3 py-1.5 text-[13px] font-medium text-primary-foreground">
                Cerrar
              </button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}

function Vacia({ icon, texto }: { icon: React.ReactNode; texto: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
      {icon}
      <p className="mt-3 max-w-sm text-center text-sm leading-relaxed">{texto}</p>
    </div>
  )
}
