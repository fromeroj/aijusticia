import { Building2, FolderKanban, Mail, Phone, User } from 'lucide-react'
import { CASOS, CLIENTES } from '@/data/mock'
import { EstadoDot, MateriaBadge, SectionLabel, fmtFecha } from '@/components/bits'
import { cn } from '@/lib/utils'

export function ClientsPage({ selectedId, onSelect, goCaso }: { selectedId: string | null; onSelect: (id: string) => void; goCaso: (id: string) => void }) {
  const sel = CLIENTES.find((c) => c.id === selectedId) ?? CLIENTES[0]
  const casosCliente = CASOS.filter((c) => c.clienteId === sel.id)

  return (
    <div className="flex h-full min-h-0">
      {/* lista */}
      <div className="w-[300px] shrink-0 overflow-y-auto border-r border-border bg-card/40">
        {CLIENTES.map((c) => (
          <button
            key={c.id}
            onClick={() => onSelect(c.id)}
            className={cn(
              'w-full border-b border-border px-4 py-3 text-left transition-colors',
              selectedId === c.id ? 'bg-primary/[0.06]' : 'hover:bg-accent/50'
            )}
          >
            <div className="flex items-center gap-2">
              {c.tipo === 'Persona moral' ? (
                <Building2 className="size-3.5 text-muted-foreground" />
              ) : (
                <User className="size-3.5 text-muted-foreground" />
              )}
              <p className={cn('truncate text-[13.5px]', selectedId === c.id ? 'font-semibold' : 'font-medium')}>{c.nombre}</p>
            </div>
            <p className="mt-1 font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">
              {CASOS.filter((k) => k.clienteId === c.id).length} casos · desde {fmtFecha(c.desde)}
            </p>
          </button>
        ))}
      </div>

      {/* detalle */}
      <div className="min-w-0 flex-1 overflow-y-auto px-8 py-6">
        <div className="max-w-3xl">
          <p className="font-mono2 text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
            {sel.tipo} · cliente desde {fmtFecha(sel.desde)}
          </p>
          <h2 className="mt-1 font-display text-[26px] font-semibold tracking-tight">{sel.nombre}</h2>

          <div className="mt-4 flex gap-3">
            <span className="flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 text-[13px]">
              <Mail className="size-3.5 text-muted-foreground" /> {sel.email}
            </span>
            <span className="flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 text-[13px]">
              <Phone className="size-3.5 text-muted-foreground" /> {sel.telefono}
            </span>
          </div>

          {sel.notas && (
            <p className="mt-4 rounded-lg border border-border bg-card p-4 text-[13.5px] leading-relaxed text-foreground/90">
              {sel.notas}
            </p>
          )}

          <div className="mt-8">
            <SectionLabel>Casos del cliente ({casosCliente.length})</SectionLabel>
            <div className="mt-3 divide-y divide-border rounded-lg border border-border bg-card">
              {casosCliente.map((k) => (
                <button
                  key={k.id}
                  onClick={() => goCaso(k.id)}
                  className="flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-accent/50"
                >
                  <FolderKanban className="size-4 text-muted-foreground" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13.5px] font-medium">{k.nombre}</p>
                    <p className="font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">{k.folio}</p>
                  </div>
                  <MateriaBadge materia={k.materia} />
                  <EstadoDot estado={k.estado} />
                </button>
              ))}
              {casosCliente.length === 0 && (
                <p className="px-4 py-6 text-center text-sm text-muted-foreground">Sin casos registrados.</p>
              )}
            </div>
          </div>

          <div className="mt-8">
            <SectionLabel>Portal del cliente</SectionLabel>
            <p className="mt-2 max-w-lg text-[13px] leading-relaxed text-muted-foreground">
              El cliente ve sus casos desde <span className="font-mono2 text-foreground">/casos</span> con la vista de
              expediente (documentos, notas y compartir). Lo que compartas con él aparece al instante en su panel — sin
              correos ni adjuntos.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
