import { useMemo, useState } from 'react'
import { AlertTriangle, CheckCircle2, ShieldCheck } from 'lucide-react'
import { CASOS, CLIENTES, cliente } from '@/data/mock'
import { SectionLabel, fmtFecha } from '@/components/bits'
import { cn } from '@/lib/utils'

interface Hallazgo {
  tipo: 'Cliente actual' | 'Cliente anterior' | 'Contraparte' | 'Caso relacionado'
  texto: string
  detalle: string
  riesgo: 'alto' | 'medio'
}

export function ConflictsPage() {
  const [q, setQ] = useState('')
  const [buscado, setBuscado] = useState(false)

  const hallazgos = useMemo<Hallazgo[]>(() => {
    const t = q.trim().toLowerCase()
    if (!t || t.length < 3) return []
    const out: Hallazgo[] = []
    CLIENTES.forEach((c) => {
      if (c.nombre.toLowerCase().includes(t)) {
        const activos = CASOS.some((k) => k.clienteId === c.id && k.estado === 'Activo')
        out.push({
          tipo: activos ? 'Cliente actual' : 'Cliente anterior',
          texto: c.nombre,
          detalle: `${CASOS.filter((k) => k.clienteId === c.id).length} caso(s) en el despacho · cliente desde ${fmtFecha(c.desde)}`,
          riesgo: activos ? 'alto' : 'medio',
        })
      }
    })
    CASOS.forEach((k) => {
      if (k.contraparte?.toLowerCase().includes(t)) {
        out.push({
          tipo: 'Contraparte',
          texto: k.contraparte,
          detalle: `En ${k.folio} — ${k.nombre} · nuestro cliente: ${cliente(k.clienteId).nombre}`,
          riesgo: k.estado === 'Activo' ? 'alto' : 'medio',
        })
      }
      if (k.nombre.toLowerCase().includes(t)) {
        out.push({
          tipo: 'Caso relacionado',
          texto: k.nombre,
          detalle: `${k.folio} · ${k.materia} · ${k.estado}`,
          riesgo: 'medio',
        })
      }
    })
    return out
  }, [q])

  return (
    <div className="h-full overflow-y-auto px-8 py-6">
      <div className="mx-auto max-w-3xl">
        <div className="flex items-center gap-3">
          <span className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary ring-1 ring-primary/25">
            <ShieldCheck className="size-5" />
          </span>
          <div>
            <h2 className="font-display text-[26px] font-semibold tracking-tight">Verificación de conflictos</h2>
            <p className="text-sm text-muted-foreground">
              Antes de aceptar un asunto, busca el nombre del prospecto y de la contraparte.
            </p>
          </div>
        </div>

        <div className="mt-6 flex gap-2">
          <input
            value={q}
            onChange={(e) => {
              setQ(e.target.value)
              setBuscado(true)
            }}
            placeholder="Ej. «Distribuidora Bento», «Jordi Font», «Alulia»…"
            className="h-11 flex-1 rounded-md border border-input bg-card px-4 text-[14px] outline-none placeholder:text-muted-foreground focus:border-primary/50"
          />
          <button className="rounded-md bg-primary px-5 text-[13.5px] font-medium text-primary-foreground transition-colors hover:bg-primary/90">
            Verificar
          </button>
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          La búsqueda cruza clientes actuales y anteriores, contrapartes y casos — incluidos los confidenciales (sin
          revelar su contenido, solo la existencia del conflicto).
        </p>

        {buscado && q.trim().length >= 3 && (
          <div className="mt-8">
            {hallazgos.length === 0 ? (
              <div className="flex items-center gap-3 rounded-lg border border-[hsl(var(--sage)/0.3)] bg-[hsl(var(--sage)/0.06)] px-5 py-4">
                <CheckCircle2 className="size-5 text-sage" />
                <div>
                  <p className="font-medium text-sage">Sin coincidencias</p>
                  <p className="text-sm text-muted-foreground">
                    Ningún registro del despacho coincide con «{q}». Puedes proceder con la admisión del cliente.
                  </p>
                </div>
              </div>
            ) : (
              <>
                <SectionLabel>{hallazgos.length} coincidencia(s) — revisar antes de aceptar</SectionLabel>
                <div className="mt-3 space-y-2">
                  {hallazgos.map((h, i) => (
                    <div
                      key={i}
                      className={cn(
                        'flex items-start gap-3 rounded-lg border px-5 py-4',
                        h.riesgo === 'alto' ? 'border-oxblood/30 bg-oxblood/[0.05]' : 'border-gold/30 bg-gold/[0.06]'
                      )}
                    >
                      <AlertTriangle className={cn('mt-0.5 size-4 shrink-0', h.riesgo === 'alto' ? 'text-oxblood' : 'text-gold')} />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="text-[14px] font-semibold">{h.texto}</p>
                          <span className={cn('rounded-full border px-2 py-0.5 text-[10px] font-medium', h.riesgo === 'alto' ? 'border-oxblood/30 text-oxblood' : 'border-gold/40 text-gold')}>
                            {h.tipo}
                          </span>
                        </div>
                        <p className="mt-1 text-[13px] text-muted-foreground">{h.detalle}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <p className="mt-4 rounded-md border border-border bg-card px-4 py-3 text-[13px] leading-relaxed text-muted-foreground">
                  Si hay conflicto potencial: documenta la verificación, considera el muro ético (vetar miembros en el
                  caso existente) y obtén consentimiento informado por escrito antes de aceptar.
                </p>
              </>
            )}
          </div>
        )}

        {!buscado && (
          <div className="mt-10 grid grid-cols-3 gap-4">
            {[
              ['Buscar primero', 'Prospecto y contraparte, siempre antes de la carta de instrucción.'],
              ['Documentar', 'La verificación queda en la bitácora de admisión del despacho.'],
              ['Muro ético', 'Si hay relación previa, veta a los miembros afectados desde el caso.'],
            ].map(([t, d]) => (
              <div key={t} className="rounded-lg border border-border bg-card p-4">
                <p className="font-display text-[15px] font-semibold">{t}</p>
                <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">{d}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export function SettingsPage() {
  return (
    <div className="h-full overflow-y-auto px-8 py-6">
      <div className="mx-auto max-w-2xl space-y-6">
        <h2 className="font-display text-[26px] font-semibold tracking-tight">Ajustes</h2>

        <section className="rounded-lg border border-border bg-card p-5">
          <SectionLabel>Identidad</SectionLabel>
          <p className="mt-2 text-[13.5px] leading-relaxed text-muted-foreground">
            Tu identidad es una frase de 12 palabras. Nunca se envía por correo: la recuperación usa un enlace de un
            solo uso con vigencia de 15 minutos.
          </p>
          <button className="mt-3 rounded-md border border-border px-3 py-1.5 text-[13px] transition-colors hover:bg-accent">
            Ver mi frase (enlace de un solo uso)
          </button>
        </section>

        <section className="rounded-lg border border-border bg-card p-5">
          <SectionLabel>Firma — Miravete & Asociados</SectionLabel>
          <p className="mt-2 text-[13.5px] leading-relaxed text-muted-foreground">
            Conectado a Nextcloud en <span className="font-mono2 text-foreground">oficina.konen.guru</span>. Los
            documentos viven en tu servidor; AI Justicia solo indexa el texto.
          </p>
          <div className="mt-3 flex gap-2">
            <button className="rounded-md border border-border px-3 py-1.5 text-[13px] transition-colors hover:bg-accent">
              + Invitar miembro (código)
            </button>
            <button className="rounded-md border border-border px-3 py-1.5 text-[13px] transition-colors hover:bg-accent">
              Abrir Nextcloud
            </button>
          </div>
        </section>

        <section className="rounded-lg border border-border bg-card p-5">
          <SectionLabel>Consentimiento LFPDPPP</SectionLabel>
          <div className="mt-2 flex items-center justify-between">
            <p className="max-w-sm text-[13.5px] leading-relaxed text-muted-foreground">
              Permitir que mis documentos anonimizados mejoren el corpus de Izel. Consentimiento independiente,
              revocable en cualquier momento.
            </p>
            <span className="rounded-full border border-[hsl(var(--sage)/0.3)] bg-[hsl(var(--sage)/0.08)] px-3 py-1 text-[11px] font-medium text-sage">
              Otorgado
            </span>
          </div>
        </section>

        <section className="rounded-lg border border-border bg-card p-5">
          <SectionLabel>Preferencias de archivos</SectionLabel>
          <div className="mt-3 flex gap-2">
            {['Abrir en editor', 'Solo descargar', 'Descargar y abrir'].map((o, i) => (
              <button
                key={o}
                className={cn(
                  'rounded-md border px-3 py-1.5 text-[13px] transition-colors',
                  i === 0 ? 'border-primary/50 bg-primary/5 font-medium text-primary' : 'border-border text-muted-foreground hover:text-foreground'
                )}
              >
                {o}
              </button>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}
