import { useMemo, useState } from 'react'
import { AlertTriangle, Plus } from 'lucide-react'
import { PLAZOS, caso } from '@/data/mock'
import { SectionLabel, diasHasta, fmtFecha } from '@/components/bits'
import { cn } from '@/lib/utils'

const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre']
const DIAS_SEMANA = ['lu', 'ma', 'mi', 'ju', 'vi', 'sá', 'do']

export function AgendaPage({ goCaso }: { goCaso: (id: string) => void }) {
  const [mes] = useState(8) // septiembre 2026 (0-indexed)
  const anio = 2026

  const celdas = useMemo(() => {
    const primero = new Date(anio, mes, 1)
    let offset = (primero.getDay() + 6) % 7 // lunes = 0
    const diasMes = new Date(anio, mes + 1, 0).getDate()
    const arr: (number | null)[] = []
    for (let i = 0; i < offset; i++) arr.push(null)
    for (let d = 1; d <= diasMes; d++) arr.push(d)
    while (arr.length % 7 !== 0) arr.push(null)
    return arr
  }, [mes, anio])

  const plazosDelDia = (d: number | null) =>
    d === null ? [] : PLAZOS.filter((p) => p.fecha === `${anio}-${String(mes + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`)

  const proximos = [...PLAZOS].sort((a, b) => a.fecha.localeCompare(b.fecha))

  return (
    <div className="flex h-full min-h-0">
      {/* calendario */}
      <div className="min-w-0 flex-1 overflow-y-auto px-8 py-6">
        <div className="mx-auto max-w-4xl">
          <div className="flex items-baseline justify-between">
            <h2 className="font-display text-[26px] font-semibold tracking-tight">
              {MESES[mes]} <span className="text-muted-foreground">{anio}</span>
            </h2>
            <button className="flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-[13px] font-medium text-primary-foreground transition-colors hover:bg-primary/90">
              <Plus className="size-4" /> Registrar plazo
            </button>
          </div>

          <div className="mt-5 overflow-hidden rounded-lg border border-border bg-card">
            <div className="grid grid-cols-7 border-b border-border bg-muted/40">
              {DIAS_SEMANA.map((d) => (
                <p key={d} className="px-3 py-2 font-mono2 text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
                  {d}
                </p>
              ))}
            </div>
            <div className="grid grid-cols-7">
              {celdas.map((d, i) => {
                const plazos = plazosDelDia(d)
                const esHoy = d === 10 && mes === 8
                return (
                  <div
                    key={i}
                    className={cn(
                      'min-h-[92px] border-b border-r border-border p-2 [&:nth-child(7n)]:border-r-0',
                      d === null && 'bg-muted/20'
                    )}
                  >
                    {d !== null && (
                      <>
                        <p
                          className={cn(
                            'flex size-6 items-center justify-center rounded-full font-mono2 text-[11px]',
                            esHoy ? 'bg-primary font-semibold text-primary-foreground' : 'text-muted-foreground'
                          )}
                        >
                          {d}
                        </p>
                        <div className="mt-1 space-y-1">
                          {plazos.map((p) => (
                            <button
                              key={p.id}
                              onClick={() => goCaso(p.casoId)}
                              title={p.titulo}
                              className={cn(
                                'block w-full truncate rounded border px-1.5 py-0.5 text-left text-[10.5px] leading-tight transition-colors',
                                p.fatal
                                  ? 'border-oxblood/25 bg-oxblood/5 text-oxblood hover:bg-oxblood/10'
                                  : 'border-primary/25 bg-primary/5 text-primary hover:bg-primary/10'
                              )}
                            >
                              {p.titulo}
                            </button>
                          ))}
                        </div>
                      </>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
          <p className="mt-3 flex items-center gap-4 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5"><span className="size-2 rounded-sm bg-oxblood/40" /> término fatal</span>
            <span className="flex items-center gap-1.5"><span className="size-2 rounded-sm bg-primary/40" /> plazo ordinario</span>
          </p>
        </div>
      </div>

      {/* lista lateral */}
      <div className="w-[320px] shrink-0 overflow-y-auto border-l border-border bg-card/40 px-5 py-6">
        <SectionLabel>Todos los plazos · por fecha</SectionLabel>
        <div className="mt-3 space-y-2">
          {proximos.map((p) => {
            const c = caso(p.casoId)
            const d = diasHasta(p.fecha)
            return (
              <button
                key={p.id}
                onClick={() => goCaso(p.casoId)}
                className="w-full rounded-lg border border-border bg-card px-3.5 py-2.5 text-left transition-colors hover:bg-accent/50"
              >
                <div className="flex items-center gap-2">
                  <p className="flex-1 truncate text-[13px] font-medium">{p.titulo}</p>
                  {p.fatal && <AlertTriangle className="size-3.5 shrink-0 text-oxblood" />}
                </div>
                <p className="mt-1 font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">
                  {fmtFecha(p.fecha)} · {c.folio} · {d < 0 ? `venció hace ${-d} d` : d === 0 ? 'hoy' : `en ${d} días`}
                </p>
              </button>
            )
          })}
        </div>
      </div>
    </div>
  )
}
