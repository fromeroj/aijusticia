import { useState } from 'react'
import { Download, FileSpreadsheet, FileText, ScanSearch, ScrollText, Tag } from 'lucide-react'
import { ARCHIVOS_BUREAU, MEMOS, PLANTILLAS } from '@/data/mock'
import { MateriaBadge, SectionLabel, fmtFecha } from '@/components/bits'
import { cn } from '@/lib/utils'

const TABS_B = [
  { id: 'plantillas', label: 'Plantillas', icon: ScrollText, count: PLANTILLAS.length },
  { id: 'memos', label: 'Memos internos', icon: FileText, count: MEMOS.length },
  { id: 'archivos', label: 'Archivos del despacho', icon: FileSpreadsheet, count: ARCHIVOS_BUREAU.length },
] as const

export type TabBiblioteca = (typeof TABS_B)[number]['id']

export function LibraryPage({ tab, onTab }: { tab: TabBiblioteca; onTab: (t: TabBiblioteca) => void }) {
  return (
    <div className="h-full overflow-y-auto px-8 py-6">
      <div className="mx-auto max-w-5xl">
        <div className="flex items-end justify-between">
          <div>
            <h2 className="font-display text-[26px] font-semibold tracking-tight">Biblioteca del despacho</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Plantillas anonimizadas, conocimiento interno y archivos operativos — de todos, para todos.
            </p>
          </div>
          <button className="rounded-md bg-primary px-3.5 py-2 text-[13px] font-medium text-primary-foreground transition-colors hover:bg-primary/90">
            + Subir a la biblioteca
          </button>
        </div>

        <div className="mt-5 flex gap-1 border-b border-border">
          {TABS_B.map((t) => (
            <button
              key={t.id}
              onClick={() => onTab(t.id)}
              className={cn(
                'flex items-center gap-2 border-b-2 px-4 py-2.5 text-[13.5px] transition-colors',
                tab === t.id
                  ? 'border-primary font-medium text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              )}
            >
              <t.icon className="size-4" />
              {t.label}
              <span className="font-mono2 text-[10px] text-muted-foreground">{t.count}</span>
            </button>
          ))}
        </div>

        <div className="py-6">
          {tab === 'plantillas' && <Plantillas />}
          {tab === 'memos' && <Memos />}
          {tab === 'archivos' && <Archivos />}
        </div>
      </div>
    </div>
  )
}

function Plantillas() {
  const [q, setQ] = useState('')
  const lista = PLANTILLAS.filter((p) => p.nombre.toLowerCase().includes(q.toLowerCase()) || p.materia.toLowerCase().includes(q.toLowerCase()))
  return (
    <div>
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Filtrar plantillas por nombre o materia…"
        className="h-9 w-80 rounded-md border border-input bg-card px-3 text-[13px] outline-none placeholder:text-muted-foreground focus:border-primary/50"
      />
      <div className="mt-4 overflow-hidden rounded-lg border border-border bg-card">
        <table className="w-full text-left text-[13px]">
          <thead>
            <tr className="border-b border-border bg-muted/50 font-mono2 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
              <th className="px-4 py-2.5 font-medium">Plantilla</th>
              <th className="px-4 py-2.5 font-medium">Materia</th>
              <th className="px-4 py-2.5 font-medium">Versión</th>
              <th className="px-4 py-2.5 font-medium">Variables</th>
              <th className="px-4 py-2.5 font-medium">Usos</th>
              <th className="px-4 py-2.5 font-medium">PII-scan</th>
              <th className="px-4 py-2.5 font-medium">Actualizada</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {lista.map((p) => (
              <tr key={p.id} className="transition-colors hover:bg-accent/40">
                <td className="px-4 py-3">
                  <p className="font-medium">{p.nombre}</p>
                  <p className="mt-0.5 max-w-md truncate text-xs text-muted-foreground">{p.descripcion}</p>
                </td>
                <td className="px-4 py-3">
                  <MateriaBadge materia={p.materia as any} />
                </td>
                <td className="px-4 py-3 font-mono2 text-[12px]">v{p.version}</td>
                <td className="px-4 py-3 font-mono2 text-[12px]">{p.variables.length}</td>
                <td className="px-4 py-3 font-mono2 text-[12px]">{p.usos}</td>
                <td className="px-4 py-3">
                  <span
                    className={cn(
                      'flex w-fit items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-medium',
                      p.piiScan === 'Limpio'
                        ? 'border-[hsl(var(--sage)/0.3)] bg-[hsl(var(--sage)/0.08)] text-sage'
                        : 'border-gold/30 bg-gold/10 text-gold'
                    )}
                  >
                    <ScanSearch className="size-3" /> {p.piiScan}
                  </span>
                </td>
                <td className="px-4 py-3 font-mono2 text-[11px] text-muted-foreground">{fmtFecha(p.actualizada)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-xs text-muted-foreground">
        Cualquier documento de un caso puede promoverse a plantilla: el PII-scan anonimiza datos personales antes de
        publicarla aquí.
      </p>
    </div>
  )
}

function Memos() {
  return (
    <div className="grid grid-cols-2 gap-4">
      {MEMOS.map((m) => (
        <article key={m.id} className="group rounded-lg border border-border bg-card p-5 transition-colors hover:border-primary/30">
          <div className="flex items-center gap-2">
            {m.materia !== 'General' && <MateriaBadge materia={m.materia as any} />}
            {m.tags.map((t) => (
              <span key={t} className="flex items-center gap-1 rounded-full border border-border px-2 py-0.5 font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">
                <Tag className="size-2.5" /> {t}
              </span>
            ))}
          </div>
          <h3 className="mt-3 font-display text-[17px] font-semibold leading-snug tracking-tight group-hover:text-primary">
            {m.titulo}
          </h3>
          <p className="mt-2 text-[13px] leading-relaxed text-muted-foreground">{m.extracto}</p>
          <p className="mt-3 font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">
            {m.autor} · {fmtFecha(m.fecha)}
          </p>
        </article>
      ))}
    </div>
  )
}

function Archivos() {
  const porCategoria = ARCHIVOS_BUREAU.reduce<Record<string, typeof ARCHIVOS_BUREAU>>((acc, a) => {
    ;(acc[a.categoria] ??= []).push(a)
    return acc
  }, {})
  return (
    <div className="space-y-6">
      {Object.entries(porCategoria).map(([cat, archivos]) => (
        <div key={cat}>
          <SectionLabel>{cat}s</SectionLabel>
          <div className="mt-2 divide-y divide-border rounded-lg border border-border bg-card">
            {archivos.map((a) => (
              <div key={a.id} className="flex items-center gap-3 px-4 py-2.5">
                {a.tipo === 'xlsx' ? (
                  <FileSpreadsheet className="size-4 text-muted-foreground" />
                ) : (
                  <FileText className="size-4 text-muted-foreground" />
                )}
                <p className="flex-1 text-[13.5px]">{a.nombre}</p>
                <p className="font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">
                  {a.tamano} · {fmtFecha(a.fecha)}
                </p>
                <button className="flex size-7 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-foreground">
                  <Download className="size-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
