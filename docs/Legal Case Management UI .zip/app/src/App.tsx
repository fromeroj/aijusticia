import { useEffect, useState } from 'react'
import { Sidebar, Topbar } from '@/components/layout'
import { CommandPalette, NotificationsSheet } from '@/components/overlays'
import { IzelRail } from '@/components/IzelRail'
import { Dashboard } from '@/pages/Dashboard'
import { CasesPage } from '@/pages/Cases'
import { ClientsPage } from '@/pages/Clients'
import { LibraryPage, type TabBiblioteca } from '@/pages/Library'
import { AgendaPage } from '@/pages/Agenda'
import { BillingPage } from '@/pages/Billing'
import { ConflictsPage, SettingsPage } from '@/pages/Conflicts'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { CASOS, NOTIFICACIONES } from '@/data/mock'
import { SectionLabel } from '@/components/bits'

export type Page =
  | 'panel'
  | 'casos'
  | 'clientes'
  | 'biblioteca'
  | 'agenda'
  | 'tiempo'
  | 'conflictos'
  | 'ajustes'

const TITULOS: Record<Page, [string, string?]> = {
  panel: ['Panel del despacho', 'Miravete & Asociados'],
  casos: ['Casos', 'El caso es el centro de todo'],
  clientes: ['Clientes', 'Directorio y portal'],
  biblioteca: ['Biblioteca', 'Plantillas · memos · archivos'],
  agenda: ['Agenda y plazos', 'Términos fatales primero'],
  tiempo: ['Tiempo y honorarios', 'Registro del despacho'],
  conflictos: ['Verificación de conflictos', 'Cumplimiento'],
  ajustes: ['Ajustes', 'Identidad · firma · privacidad'],
}

export default function App() {
  const [page, setPage] = useState<Page>('casos')
  const [casoId, setCasoId] = useState<string | null>('k1')
  const [clienteId, setClienteId] = useState<string | null>('c1')
  const [tabBiblio, setTabBiblio] = useState<TabBiblioteca>('plantillas')
  const [dark, setDark] = useState(false)
  const [paletteOpen, setPaletteOpen] = useState(false)
  const [notifOpen, setNotifOpen] = useState(false)
  const [nuevoCaso, setNuevoCaso] = useState(false)

  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark)
  }, [dark])

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        setPaletteOpen((v) => !v)
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [])

  const goCaso = (id: string) => {
    setCasoId(id)
    setPage('casos')
  }
  const goCliente = (id: string) => {
    setClienteId(id)
    setPage('clientes')
  }
  const goBiblioteca = (tab: TabBiblioteca) => {
    setTabBiblio(tab)
    setPage('biblioteca')
  }

  const casoActivo = CASOS.find((c) => c.id === casoId) ?? null
  const [titulo, subtitulo] = TITULOS[page]
  const unread = NOTIFICACIONES.filter((n) => !n.leida).length
  const conIzel = page === 'casos' || page === 'panel'

  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground">
      <Sidebar page={page} onNavigate={setPage} />

      <div className="flex min-w-0 flex-1 flex-col">
        <Topbar
          title={titulo}
          subtitle={subtitulo}
          unread={unread}
          dark={dark}
          onToggleDark={() => setDark(!dark)}
          onOpenSearch={() => setPaletteOpen(true)}
          onOpenNotifications={() => setNotifOpen(true)}
          onNewCase={() => setNuevoCaso(true)}
        />

        <main className="flex min-h-0 flex-1">
          <div className="min-w-0 flex-1 overflow-hidden">
            {page === 'panel' && <Dashboard goCaso={goCaso} goAgenda={() => setPage('agenda')} />}
            {page === 'casos' && <CasesPage selectedId={casoId} onSelect={setCasoId} />}
            {page === 'clientes' && <ClientsPage selectedId={clienteId} onSelect={setClienteId} goCaso={goCaso} />}
            {page === 'biblioteca' && <LibraryPage tab={tabBiblio} onTab={setTabBiblio} />}
            {page === 'agenda' && <AgendaPage goCaso={goCaso} />}
            {page === 'tiempo' && <BillingPage />}
            {page === 'conflictos' && <ConflictsPage />}
            {page === 'ajustes' && <SettingsPage />}
          </div>
          {conIzel && <IzelRail casoActivo={page === 'casos' ? casoActivo : null} />}
        </main>
      </div>

      <CommandPalette
        open={paletteOpen}
        onClose={() => setPaletteOpen(false)}
        goCaso={goCaso}
        goCliente={goCliente}
        goBiblioteca={goBiblioteca}
      />
      <NotificationsSheet open={notifOpen} onClose={() => setNotifOpen(false)} goCaso={goCaso} />

      <Dialog open={nuevoCaso} onOpenChange={setNuevoCaso}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display">Nuevo caso</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <SectionLabel>Nombre del caso</SectionLabel>
              <input
                placeholder="Ej. Pérez vs. Inmobiliaria Sur — arrendamiento"
                className="mt-1.5 h-9 w-full rounded-md border border-input bg-background px-3 text-[13.5px] outline-none placeholder:text-muted-foreground focus:border-primary/50"
              />
            </div>
            <div>
              <SectionLabel>Materia</SectionLabel>
              <div className="mt-1.5 flex flex-wrap gap-1.5">
                {['Civil', 'Mercantil', 'Laboral', 'Familiar', 'Penal', 'Amparo', 'Administrativo', 'Fiscal'].map((m, i) => (
                  <button
                    key={m}
                    className={
                      'rounded-full border px-3 py-1 text-[12px] transition-colors ' +
                      (i === 1 ? 'border-primary/50 bg-primary/10 text-primary' : 'border-border text-muted-foreground hover:text-foreground')
                    }
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>
            <p className="text-xs leading-relaxed text-muted-foreground">
              Al crearlo puedes generar un código de invitación para que tu cliente lo vea desde su portal — con
              aceptación obligatoria, nunca acceso directo.
            </p>
            <button
              onClick={() => setNuevoCaso(false)}
              className="w-full rounded-md bg-primary py-2 text-[13.5px] font-medium text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Crear caso
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
