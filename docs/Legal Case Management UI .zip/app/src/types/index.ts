export type Materia =
  | 'Civil'
  | 'Mercantil'
  | 'Laboral'
  | 'Familiar'
  | 'Penal'
  | 'Amparo'
  | 'Administrativo'
  | 'Fiscal'

export type EstadoCaso = 'Activo' | 'En espera' | 'Suspendido' | 'Concluido' | 'Archivado'

export type RolCaso = 'Responsable' | 'Abogado' | 'Pasante'
export type RolFirma = 'Socio' | 'Admin' | 'Abogado' | 'Pasante'

export interface Miembro {
  id: string
  nombre: string
  iniciales: string
  rol: RolFirma
  email: string
}

export interface Asignacion {
  miembroId: string
  rol: RolCaso
}

export interface Veto {
  miembroId: string
  razon: string
  fecha: string
}

export interface Cliente {
  id: string
  nombre: string
  tipo: 'Persona física' | 'Persona moral'
  email: string
  telefono: string
  desde: string
  notas?: string
}

export interface Documento {
  id: string
  nombre: string
  version: number
  versiones: number
  tipo: 'docx' | 'pdf' | 'img' | 'xlsx'
  tamano: string
  metodo: 'Texto' | 'OCR'
  fecha: string
  autor: string
  contenido?: string[]
}

export interface Nota {
  id: string
  autor: string
  fecha: string
  texto: string
}

export interface EventoTimeline {
  id: string
  fecha: string
  tipo: 'creacion' | 'documento' | 'nota' | 'acceso' | 'asignacion' | 'plazo' | 'tarea' | 'version'
  texto: string
  autor?: string
}

export interface Plazo {
  id: string
  casoId: string
  titulo: string
  fecha: string
  fatal: boolean
  tipo: 'Término' | 'Audiencia' | 'Vencimiento' | 'Entrega' | 'Junta'
  cumplido?: boolean
}

export interface Tarea {
  id: string
  casoId: string
  titulo: string
  asignado: string
  vence: string
  hecha: boolean
}

export interface Caso {
  id: string
  folio: string
  nombre: string
  materia: Materia
  estado: EstadoCaso
  clienteId: string
  contraparte?: string
  jurisdiccion: string
  juzgado?: string
  expedienteJudicial?: string
  descripcion: string
  confidencial: boolean
  compartido?: boolean
  origen?: string
  creado: string
  actualizado: string
  equipo: Asignacion[]
  vetos: Veto[]
  documentos: Documento[]
  notas: Nota[]
  timeline: EventoTimeline[]
  etapa: string
  horas: number
  honorarios: number
}

export interface Plantilla {
  id: string
  nombre: string
  materia: Materia
  descripcion: string
  variables: string[]
  version: number
  usos: number
  actualizada: string
  piiScan: 'Limpio' | 'Pendiente'
  autor: string
}

export interface Memo {
  id: string
  titulo: string
  materia: Materia | 'General'
  autor: string
  fecha: string
  tags: string[]
  extracto: string
}

export interface ArchivoBureau {
  id: string
  nombre: string
  categoria: 'Formato' | 'Política' | 'Directorio' | 'Guía'
  tipo: 'docx' | 'pdf' | 'xlsx'
  fecha: string
  tamano: string
}

export interface RegistroTiempo {
  id: string
  casoId: string
  miembroId: string
  fecha: string
  horas: number
  concepto: string
  facturable: boolean
}

export interface Notificacion {
  id: string
  tipo: 'plazo' | 'compartido' | 'nota' | 'tarea' | 'solicitud'
  texto: string
  detalle: string
  fecha: string
  leida: boolean
}
