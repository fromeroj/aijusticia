import type {
  ArchivoBureau,
  Caso,
  Cliente,
  Memo,
  Miembro,
  Notificacion,
  Plazo,
  Plantilla,
  RegistroTiempo,
  Tarea,
} from '@/types'

export const FIRMA = {
  nombre: 'Miravete & Asociados',
  plan: 'Despacho',
  servidor: 'oficina.konen.guru',
}

export const USUARIO: Miembro = {
  id: 'm1',
  nombre: 'Max Iriarte',
  iniciales: 'MI',
  rol: 'Socio',
  email: 'max@miravete.mx',
}

export const MIEMBROS: Miembro[] = [
  USUARIO,
  { id: 'm2', nombre: 'Lucía Ferrán', iniciales: 'LF', rol: 'Admin', email: 'lucia@miravete.mx' },
  { id: 'm3', nombre: 'Diego Salcedo', iniciales: 'DS', rol: 'Abogado', email: 'diego@miravete.mx' },
  { id: 'm4', nombre: 'Renata Obregón', iniciales: 'RO', rol: 'Abogado', email: 'renata@miravete.mx' },
  { id: 'm5', nombre: 'Tomás Villa', iniciales: 'TV', rol: 'Pasante', email: 'tomas@miravete.mx' },
]

export const CLIENTES: Cliente[] = [
  { id: 'c1', nombre: 'Pari Cortázar', tipo: 'Persona física', email: 'pari@estudio-norte.mx', telefono: '55 4410 2210', desde: '2026-03-14', notas: 'Fundadora de Estudio Norte. Prefiere comunicación por WhatsApp.' },
  { id: 'c2', nombre: 'Grupo Alulia, S.A. de C.V.', tipo: 'Persona moral', email: 'legal@alulia.mx', telefono: '55 9032 1188', desde: '2025-11-02' },
  { id: 'c3', nombre: 'Ernesto Belli', tipo: 'Persona física', email: 'ernesto.belli@gmail.com', telefono: '55 7712 9045', desde: '2026-06-21' },
  { id: 'c4', nombre: 'Inmobiliaria del Pedregal, S.A.', tipo: 'Persona moral', email: 'direccion@inmobpedregal.mx', telefono: '55 5601 3345', desde: '2024-08-19' },
  { id: 'c5', nombre: 'Marcela y Jordi Font', tipo: 'Persona física', email: 'marcela.font@outlook.com', telefono: '55 2280 6631', desde: '2026-07-30' },
  { id: 'c6', nombre: 'Talleres Kovac, S. de R.L.', tipo: 'Persona moral', email: 'admin@kovac.mx', telefono: '81 2091 4470', desde: '2025-04-08' },
  { id: 'c7', nombre: 'Fundación Vivero, A.C.', tipo: 'Persona moral', email: 'contacto@fvivero.org', telefono: '55 6145 0092', desde: '2026-01-25' },
]

const actaContenido = [
  'ACTA CONSTITUTIVA — ESTUDIO NORTE, S.A.P.I. DE C.V.',
  'Libro primero de actas · Protocolo ante Fedatario Público núm. 42, CDMX',
  '',
  'CLÁUSULA PRIMERA. DENOMINACIÓN. La sociedad se denominará «Estudio Norte, S.A.P.I. de C.V.», …',
  'CLÁUSULA SÉPTIMA. CAPITAL SOCIAL. El capital social mínimo fijo, sin derecho de retiro, es de $250,000.00 M.N., …',
  'CLÁUSULA DÉCIMA SEGUNDA. ADMINISTRACIÓN. La administración estará a cargo de un Consejo de Administración integrado por …',
  'CLÁUSULA DÉCIMA QUINTA. ADMISIÓN DE ACCIONISTAS. Las acciones de la serie «B» conferirán derechos corporativos limitados conforme al art. 112 de la LGSM …',
]

export const CASOS: Caso[] = [
  {
    id: 'k1',
    folio: 'MRC-2026-014',
    nombre: 'Constitución Estudio Norte, S.A.P.I.',
    materia: 'Mercantil',
    estado: 'Activo',
    clienteId: 'c1',
    jurisdiccion: 'CDMX',
    descripcion:
      'Constitución de sociedad anónima promotora de inversión. Iteración del acta constitutiva con la fundadora: definición de serie bursátil vs. no bursátil, estructura de gobierno y jerarquía de cláusulas de admisión.',
    confidencial: false,
    compartido: true,
    origen: 'Compartido por Pari Cortázar',
    creado: '2026-08-12',
    actualizado: '2026-09-08',
    etapa: 'Redacción de acta v3',
    horas: 14.5,
    honorarios: 58000,
    equipo: [
      { miembroId: 'm1', rol: 'Responsable' },
      { miembroId: 'm5', rol: 'Pasante' },
    ],
    vetos: [],
    documentos: [
      { id: 'd1', nombre: 'acta_constitutiva_estudio_norte.docx', version: 2, versiones: 2, tipo: 'docx', tamano: '84 KB', metodo: 'Texto', fecha: '2026-09-04', autor: 'Pari Cortázar', contenido: actaContenido },
      { id: 'd2', nombre: 'identificacion_fundadora.pdf', version: 1, versiones: 1, tipo: 'pdf', tamano: '1.2 MB', metodo: 'OCR', fecha: '2026-08-14', autor: 'Pari Cortázar' },
      { id: 'd3', nombre: 'comprobante_domicilio.jpg', version: 1, versiones: 1, tipo: 'img', tamano: '640 KB', metodo: 'OCR', fecha: '2026-08-14', autor: 'Pari Cortázar' },
      { id: 'd4', nombre: 'tabla_capital_series.xlsx', version: 1, versiones: 1, tipo: 'xlsx', tamano: '22 KB', metodo: 'Texto', fecha: '2026-09-01', autor: 'Max Iriarte' },
    ],
    notas: [
      { id: 'n1', autor: 'Max Iriarte', fecha: '2026-09-04 18:22', texto: 'Revisé la v2. Dos puntos: (1) la cláusula séptima sigue hablando de serie bursátil, pero el consejo acordó SAPI no bursátil — hay que ajustar el régimen de transferencia de acciones; (2) la jerarquía entre el pacto de socios y el acta debe quedar expresa en la décima quinta.' },
      { id: 'n2', autor: 'Pari Cortázar', fecha: '2026-09-06 10:05', texto: 'De acuerdo en ambos. Subo la v3 con la serie «B» no bursátil y remisión expresa al pacto. ¿Podemos agendar la firma para la semana del 21?' },
      { id: 'n3', autor: 'Tomás Villa', fecha: '2026-09-08 09:41', texto: 'Verifiqué disponibilidad del fedatario núm. 42: tiene agenda abierta el 23 y 24 de septiembre por la mañana.' },
    ],
    timeline: [
      { id: 't1', fecha: '2026-08-12', tipo: 'creacion', texto: 'Caso creado por Pari Cortázar desde el chat de Izel', autor: 'Pari Cortázar' },
      { id: 't2', fecha: '2026-08-13', tipo: 'acceso', texto: 'Invitación aceptada — acceso otorgado a Miravete & Asociados', autor: 'Pari Cortázar' },
      { id: 't3', fecha: '2026-08-14', tipo: 'documento', texto: 'Documento nuevo: identificacion_fundadora.pdf (OCR)', autor: 'Pari Cortázar' },
      { id: 't4', fecha: '2026-08-19', tipo: 'documento', texto: 'acta_constitutiva_estudio_norte.docx — versión 1', autor: 'Pari Cortázar' },
      { id: 't5', fecha: '2026-08-22', tipo: 'asignacion', texto: 'Tomás Villa asignado como Pasante', autor: 'Max Iriarte' },
      { id: 't6', fecha: '2026-09-04', tipo: 'version', texto: 'acta_constitutiva_estudio_norte.docx — versión 2', autor: 'Pari Cortázar' },
      { id: 't7', fecha: '2026-09-04', tipo: 'nota', texto: 'Nota de revisión: serie bursátil vs. no bursátil, jerarquía pacto/acta', autor: 'Max Iriarte' },
      { id: 't8', fecha: '2026-09-08', tipo: 'plazo', texto: 'Plazo registrado: junta de consejo para aprobar v3', autor: 'Max Iriarte' },
    ],
  },
  {
    id: 'k2',
    folio: 'MRC-2026-011',
    nombre: 'Alulia vs. Distribuidora Bento — Juicio ordinario mercantil',
    materia: 'Mercantil',
    estado: 'Activo',
    clienteId: 'c2',
    contraparte: 'Distribuidora Bento, S.A. de C.V.',
    jurisdiccion: 'CDMX',
    juzgado: 'Juzgado 6° de lo Civil y Mercantil',
    expedienteJudicial: '1184/2026',
    descripcion: 'Cobro de $2.4 M.N. por incumplimiento de contrato de suministro. Etapa de ofrecimiento y admisión de pruebas.',
    confidencial: false,
    creado: '2026-05-30',
    actualizado: '2026-09-09',
    etapa: 'Pruebas',
    horas: 61,
    honorarios: 244000,
    equipo: [
      { miembroId: 'm1', rol: 'Responsable' },
      { miembroId: 'm3', rol: 'Abogado' },
    ],
    vetos: [],
    documentos: [
      { id: 'd5', nombre: 'demanda_ordinaria_mercantil.docx', version: 1, versiones: 1, tipo: 'docx', tamano: '156 KB', metodo: 'Texto', fecha: '2026-06-02', autor: 'Max Iriarte' },
      { id: 'd6', nombre: 'contrato_suministro_2024.pdf', version: 1, versiones: 1, tipo: 'pdf', tamano: '3.8 MB', metodo: 'OCR', fecha: '2026-06-02', autor: 'Diego Salcedo' },
      { id: 'd7', nombre: 'facturas_periodo_ene_jun.pdf', version: 1, versiones: 1, tipo: 'pdf', tamano: '7.1 MB', metodo: 'OCR', fecha: '2026-06-10', autor: 'Diego Salcedo' },
      { id: 'd8', nombre: 'contesta_demanda_bento.pdf', version: 1, versiones: 1, tipo: 'pdf', tamano: '2.2 MB', metodo: 'OCR', fecha: '2026-08-21', autor: 'Notificación' },
    ],
    notas: [
      { id: 'n4', autor: 'Diego Salcedo', fecha: '2026-08-25 12:14', texto: 'La contraparte alega vicios del consentimiento. Nuestra prueba confesional es la llave: citar a su representante antes del cierre del periodo probatorio.' },
      { id: 'n5', autor: 'Max Iriarte', fecha: '2026-09-09 16:40', texto: 'Se admitieron las periciales en contabilidad. Preparar cuestionario con Tomás antes del viernes.' },
    ],
    timeline: [
      { id: 't9', fecha: '2026-05-30', tipo: 'creacion', texto: 'Caso creado — Grupo Alulia', autor: 'Max Iriarte' },
      { id: 't10', fecha: '2026-06-02', tipo: 'documento', texto: 'Demanda presentada — exp. 1184/2026', autor: 'Max Iriarte' },
      { id: 't11', fecha: '2026-08-21', tipo: 'documento', texto: 'Contestación de la demanda notificada', autor: 'Sistema' },
      { id: 't12', fecha: '2026-09-09', tipo: 'nota', texto: 'Periciales admitidas en contabilidad', autor: 'Max Iriarte' },
    ],
  },
  {
    id: 'k3',
    folio: 'MRC-2026-019',
    nombre: 'Belli — Despido injustificado',
    materia: 'Laboral',
    estado: 'Activo',
    clienteId: 'c3',
    contraparte: 'Logística Ferroquinto, S.A.',
    jurisdiccion: 'CDMX',
    juzgado: 'Centro Federal de Conciliación — Tribunal Laboral',
    expedienteJudicial: 'CF-2209/2026',
    descripcion: 'Reinstalación o indemnización constitucional por despido sin causa. Audiencia inicial celebrada; se agotó la etapa conciliatoria sin acuerdo.',
    confidencial: false,
    creado: '2026-07-15',
    actualizado: '2026-09-02',
    etapa: 'Audiencia de juicio',
    horas: 22,
    honorarios: 66000,
    equipo: [
      { miembroId: 'm4', rol: 'Responsable' },
      { miembroId: 'm5', rol: 'Pasante' },
    ],
    vetos: [],
    documentos: [
      { id: 'd9', nombre: 'demanda_laboral_belli.docx', version: 1, versiones: 1, tipo: 'docx', tamano: '98 KB', metodo: 'Texto', fecha: '2026-07-16', autor: 'Renata Obregón' },
      { id: 'd10', nombre: 'acta_audiencia_inicial.pdf', version: 1, versiones: 1, tipo: 'pdf', tamano: '900 KB', metodo: 'OCR', fecha: '2026-08-28', autor: 'Renata Obregón' },
    ],
    notas: [
      { id: 'n6', autor: 'Renata Obregón', fecha: '2026-08-29 09:12', texto: 'El patrón ofreció 60 días de salario en conciliación — rechazado. El cliente prefiere reinstalación; evaluar riesgo de que Ferroquinto acredite causal de rescisión.' },
    ],
    timeline: [
      { id: 't13', fecha: '2026-07-15', tipo: 'creacion', texto: 'Caso creado — Ernesto Belli', autor: 'Renata Obregón' },
      { id: 't14', fecha: '2026-08-28', tipo: 'plazo', texto: 'Audiencia inicial celebrada sin acuerdo conciliatorio', autor: 'Renata Obregón' },
    ],
  },
  {
    id: 'k4',
    folio: 'MRC-2025-147',
    nombre: 'Inmobiliaria del Pedregal — Contratos de arrendamiento',
    materia: 'Civil',
    estado: 'Activo',
    clienteId: 'c4',
    jurisdiccion: 'CDMX',
    descripcion: 'Portafolio recurrente: revisión y actualización de 14 contratos de arrendamiento comercial a la reforma del Código Civil CDMX (2026).',
    confidencial: false,
    creado: '2025-11-10',
    actualizado: '2026-09-05',
    etapa: 'Revisión 9 de 14',
    horas: 38,
    honorarios: 152000,
    equipo: [
      { miembroId: 'm3', rol: 'Responsable' },
    ],
    vetos: [],
    documentos: [
      { id: 'd11', nombre: 'arrendamiento_local_14_polanco.docx', version: 3, versiones: 3, tipo: 'docx', tamano: '61 KB', metodo: 'Texto', fecha: '2026-09-05', autor: 'Diego Salcedo' },
    ],
    notas: [],
    timeline: [
      { id: 't15', fecha: '2025-11-10', tipo: 'creacion', texto: 'Caso creado — servicio recurrente', autor: 'Diego Salcedo' },
    ],
  },
  {
    id: 'k5',
    folio: 'MRC-2026-021',
    nombre: 'Font — Divorcio necesario y convenio de custodia',
    materia: 'Familiar',
    estado: 'En espera',
    clienteId: 'c5',
    contraparte: 'Jordi Font',
    jurisdiccion: 'CDMX',
    juzgado: 'Juzgado 12° de lo Familiar',
    descripcion: 'Divorcio necesario por separación de más de dos años. Convenio de custodia compartida y pensión alimenticia en negociación.',
    confidencial: true,
    creado: '2026-08-01',
    actualizado: '2026-08-30',
    etapa: 'Negociación de convenio',
    horas: 11,
    honorarios: 44000,
    equipo: [
      { miembroId: 'm1', rol: 'Responsable' },
    ],
    vetos: [{ miembroId: 'm5', razon: 'Relación familiar con la contraparte', fecha: '2026-08-02' }],
    documentos: [],
    notas: [
      { id: 'n7', autor: 'Max Iriarte', fecha: '2026-08-02 11:30', texto: 'Caso marcado como confidencial. Tomás vetado por relación familiar con la contraparte — muro ético activo.' },
    ],
    timeline: [
      { id: 't16', fecha: '2026-08-01', tipo: 'creacion', texto: 'Caso creado — Marcela Font', autor: 'Max Iriarte' },
      { id: 't17', fecha: '2026-08-02', tipo: 'asignacion', texto: 'Muro ético: Tomás Villa vetado (relación familiar)', autor: 'Max Iriarte' },
    ],
  },
  {
    id: 'k6',
    folio: 'MRC-2026-007',
    nombre: 'Talleres Kovac — Amparo indirecto vs. clausura',
    materia: 'Amparo',
    estado: 'Activo',
    clienteId: 'c6',
    contraparte: 'STPS / Municipio de Monterrey',
    jurisdiccion: 'Nuevo León',
    juzgado: 'Juzgado 3° de Distrito en Materia Administrativa',
    expedienteJudicial: 'AID-441/2026',
    descripcion: 'Amparo indirecto contra orden de clausura por presuntas irregularidades de seguridad e higiene. Suspensión de plano concedida.',
    confidencial: false,
    creado: '2026-04-22',
    actualizado: '2026-09-07',
    etapa: 'Incidente de suspensión',
    horas: 29,
    honorarios: 116000,
    equipo: [
      { miembroId: 'm4', rol: 'Responsable' },
    ],
    vetos: [],
    documentos: [
      { id: 'd12', nombre: 'demanda_amparo_indirecto.docx', version: 2, versiones: 2, tipo: 'docx', tamano: '210 KB', metodo: 'Texto', fecha: '2026-04-25', autor: 'Renata Obregón' },
    ],
    notas: [],
    timeline: [
      { id: 't18', fecha: '2026-04-22', tipo: 'creacion', texto: 'Caso creado — Talleres Kovac', autor: 'Renata Obregón' },
      { id: 't19', fecha: '2026-05-06', tipo: 'plazo', texto: 'Suspensión de plano concedida', autor: 'Sistema' },
    ],
  },
  {
    id: 'k7',
    folio: 'MRC-2025-203',
    nombre: 'Fundación Vivero — Dictamen de donataria autorizada',
    materia: 'Fiscal',
    estado: 'Concluido',
    clienteId: 'c7',
    jurisdiccion: 'CDMX',
    descripcion: 'Dictamen fiscal para renovación de autorización como donataria (SAT). Cierre con resolución favorable.',
    confidencial: false,
    creado: '2025-12-01',
    actualizado: '2026-03-18',
    etapa: 'Concluido',
    horas: 17,
    honorarios: 68000,
    equipo: [{ miembroId: 'm3', rol: 'Responsable' }],
    vetos: [],
    documentos: [],
    notas: [],
    timeline: [
      { id: 't20', fecha: '2025-12-01', tipo: 'creacion', texto: 'Caso creado — Fundación Vivero', autor: 'Diego Salcedo' },
    ],
  },
]

export const PLAZOS: Plazo[] = [
  { id: 'p1', casoId: 'k2', titulo: 'Desahogo de confesional — representante Bento', fecha: '2026-09-14', fatal: true, tipo: 'Término' },
  { id: 'p2', casoId: 'k1', titulo: 'Junta de consejo — aprobación acta v3', fecha: '2026-09-16', fatal: false, tipo: 'Junta' },
  { id: 'p3', casoId: 'k3', titulo: 'Audiencia de juicio (Belli vs. Ferroquinto)', fecha: '2026-09-18', fatal: true, tipo: 'Audiencia' },
  { id: 'p4', casoId: 'k1', titulo: 'Entrega de acta v3 corregida a la fundadora', fecha: '2026-09-19', fatal: false, tipo: 'Entrega' },
  { id: 'p5', casoId: 'k6', titulo: 'Informe justificado — incidente de suspensión', fecha: '2026-09-22', fatal: true, tipo: 'Término' },
  { id: 'p6', casoId: 'k4', titulo: 'Entrega contratos 10 y 11 — arrendamiento', fecha: '2026-09-25', fatal: false, tipo: 'Entrega' },
  { id: 'p7', casoId: 'k2', titulo: 'Ofrecimiento de prueba pericial complementaria', fecha: '2026-09-30', fatal: true, tipo: 'Vencimiento' },
  { id: 'p8', casoId: 'k5', titulo: 'Junta de mediación con Jordi Font', fecha: '2026-10-06', fatal: false, tipo: 'Junta' },
  { id: 'p9', casoId: 'k3', titulo: 'Ratificación de demanda — Ernesto Belli', fecha: '2026-09-11', fatal: true, tipo: 'Término' },
  { id: 'p10', casoId: 'k6', titulo: 'Presentación de pruebas instrumentales', fecha: '2026-10-09', fatal: true, tipo: 'Vencimiento' },
]

export const TAREAS: Tarea[] = [
  { id: 'ta1', casoId: 'k2', titulo: 'Preparar cuestionario de pericial en contabilidad', asignado: 'm5', vence: '2026-09-12', hecha: false },
  { id: 'ta2', casoId: 'k2', titulo: 'Citar al representante de Bento para confesional', asignado: 'm3', vence: '2026-09-13', hecha: false },
  { id: 'ta3', casoId: 'k1', titulo: 'Revisar remisión pacto de socios en acta v3', asignado: 'm1', vence: '2026-09-15', hecha: false },
  { id: 'ta4', casoId: 'k1', titulo: 'Confirmar agenda del fedatario núm. 42', asignado: 'm5', vence: '2026-09-12', hecha: true },
  { id: 'ta5', casoId: 'k3', titulo: 'Anexar cálculo de indemnización constitucional', asignado: 'm4', vence: '2026-09-16', hecha: false },
  { id: 'ta6', casoId: 'k4', titulo: 'Actualizar cláusula de fianza — locales 10 y 11', asignado: 'm3', vence: '2026-09-22', hecha: false },
]

export const PLANTILLAS: Plantilla[] = [
  { id: 'pl1', nombre: 'Acta constitutiva — S.A.P.I. de C.V.', materia: 'Mercantil', descripcion: 'Acta con cláusulas de admisión, series de acciones y gobierno corporativo para SAPI no bursátil.', variables: ['denominacion', 'capital_minimo', 'domicilio_social', 'consejeros', 'fedatario'], version: 4, usos: 12, actualizada: '2026-08-29', piiScan: 'Limpio', autor: 'Max Iriarte' },
  { id: 'pl2', nombre: 'Demanda — Juicio ordinario mercantil', materia: 'Mercantil', descripcion: 'Con capítulos de pruebas y puntos petitorios para cobro de prestaciones.', variables: ['actora', 'demandada', 'monto', 'contrato', 'juzgado'], version: 7, usos: 31, actualizada: '2026-07-12', piiScan: 'Limpio', autor: 'Max Iriarte' },
  { id: 'pl3', nombre: 'Demanda — Despido injustificado (Tribunal Laboral)', materia: 'Laboral', descripcion: 'Conforme a la reforma laboral 2019; incluye cálculo de indemnización constitucional.', variables: ['trabajador', 'patron', 'salario', 'antiguedad', 'fecha_despido'], version: 3, usos: 9, actualizada: '2026-06-30', piiScan: 'Limpio', autor: 'Renata Obregón' },
  { id: 'pl4', nombre: 'Contrato de arrendamiento comercial — CDMX', materia: 'Civil', descripcion: 'Actualizado a la reforma del Código Civil 2026; cláusula de fianza y obligación solidaria.', variables: ['arrendador', 'arrendatario', 'inmueble', 'renta', 'vigencia'], version: 5, usos: 24, actualizada: '2026-09-01', piiScan: 'Limpio', autor: 'Diego Salcedo' },
  { id: 'pl5', nombre: 'Convenio de divorcio y custodia compartida', materia: 'Familiar', descripcion: 'Con calendario de convivencias, pensión alimenticia y cláusula de revisión anual.', variables: ['cónyuge_a', 'cónyuge_b', 'hijos', 'pension', 'bienes'], version: 2, usos: 5, actualizada: '2026-05-19', piiScan: 'Limpio', autor: 'Lucía Ferrán' },
  { id: 'pl6', nombre: 'Demanda de amparo indirecto — actos de autoridad', materia: 'Amparo', descripcion: 'Con capítulo de suspensión (plano / de oficio) y conceptos de violación.', variables: ['quejoso', 'autoridad_responsable', 'acto_reclamado', 'juzgado_distrito'], version: 6, usos: 14, actualizada: '2026-04-10', piiScan: 'Pendiente', autor: 'Renata Obregón' },
  { id: 'pl7', nombre: 'Poder general para pleitos y cobranzas', materia: 'General' as any, descripcion: 'Con cláusulas especiales conforme a los arts. 2554 y 2587 del Código Civil Federal.', variables: ['poderdante', 'apoderado', 'alcance', 'fedatario'], version: 8, usos: 47, actualizada: '2026-08-05', piiScan: 'Limpio', autor: 'Max Iriarte' },
  { id: 'pl8', nombre: 'Carta de instrucción al cliente — inicio de caso', materia: 'General' as any, descripcion: 'Documentos por recabar, medios de contacto, política de confidencialidad y consentimiento LFPDPPP.', variables: ['cliente', 'caso', 'responsable'], version: 3, usos: 19, actualizada: '2026-07-22', piiScan: 'Limpio', autor: 'Lucía Ferrán' },
]

export const MEMOS: Memo[] = [
  { id: 'me1', titulo: 'Criterio SCJN: prisión preventiva oficiosa inconstitucional', materia: 'Penal', autor: 'Renata Obregón', fecha: '2026-08-15', tags: ['SCJN', 'Amparo', 'Actualización'], extracto: 'La Primera Sala resolvió la contradicción de tesis 293/2025: el catálogo del art. 19 constitucional no puede ampliarse por decreto…' },
  { id: 'me2', titulo: 'Reforma al Código Civil CDMX 2026 — lo que cambia en arrendamiento', materia: 'Civil', autor: 'Diego Salcedo', fecha: '2026-07-30', tags: ['Arrendamiento', 'CDMX', 'Reforma'], extracto: 'Tres cambios operativos: tope de fianzas, registro electrónico de contratos y nuevos supuestos de rescisión anticipada…' },
  { id: 'me3', titulo: 'Checklist de admisión de cliente nuevo (KYC + conflicto)', materia: 'General', autor: 'Lucía Ferrán', fecha: '2026-06-11', tags: ['Proceso', 'Cumplimiento'], extracto: 'Antes de firmar carta de instrucción: búsqueda de conflicto, identificación oficial, comprobante y origen de recursos…' },
  { id: 'me4', titulo: 'SAPI bursátil vs. no bursátil — guía rápida para clientes', materia: 'Mercantil', autor: 'Max Iriarte', fecha: '2026-09-02', tags: ['SAPI', 'CNBV', 'Gobierno corporativo'], extracto: 'La diferencia práctica no es la bolsa: es el régimen de supresión de derecho de preferencia y la admisión de accionistas…' },
  { id: 'me5', titulo: 'Criterios del TFJA sobre multas por clausura municipal', materia: 'Administrativo', autor: 'Renata Obregón', fecha: '2026-05-20', tags: ['TFJA', 'Clausura', 'Suspensión'], extracto: 'La Sala Superior ha sostenido que la clausura requiere visita de inspección previa con citatorio en forma…' },
]

export const ARCHIVOS_BUREAU: ArchivoBureau[] = [
  { id: 'a1', nombre: 'Política de confidencialidad y muro ético.pdf', categoria: 'Política', tipo: 'pdf', fecha: '2026-01-15', tamano: '320 KB' },
  { id: 'a2', nombre: 'Tarifario de honorarios 2026.xlsx', categoria: 'Política', tipo: 'xlsx', fecha: '2026-01-05', tamano: '44 KB' },
  { id: 'a3', nombre: 'Directorio de peritos colaboradores.xlsx', categoria: 'Directorio', tipo: 'xlsx', fecha: '2026-08-18', tamano: '58 KB' },
  { id: 'a4', nombre: 'Guía de uso de Izel para el despacho.pdf', categoria: 'Guía', tipo: 'pdf', fecha: '2026-09-01', tamano: '1.1 MB' },
  { id: 'a5', nombre: 'Formato de registro de tiempo semanal.xlsx', categoria: 'Formato', tipo: 'xlsx', fecha: '2026-02-10', tamano: '30 KB' },
  { id: 'a6', nombre: 'Formato de carta responsiva LFPDPPP.docx', categoria: 'Formato', tipo: 'docx', fecha: '2026-03-03', tamano: '26 KB' },
  { id: 'a7', nombre: 'Directorio de fedatarios CDMX y EDOMEX.xlsx', categoria: 'Directorio', tipo: 'xlsx', fecha: '2026-07-14', tamano: '62 KB' },
]

export const TIEMPO: RegistroTiempo[] = [
  { id: 'r1', casoId: 'k2', miembroId: 'm1', fecha: '2026-09-09', horas: 3.5, concepto: 'Revisión de admisión de periciales', facturable: true },
  { id: 'r2', casoId: 'k1', miembroId: 'm1', fecha: '2026-09-08', horas: 2, concepto: 'Nota de revisión acta v2 — régimen de series', facturable: true },
  { id: 'r3', casoId: 'k1', miembroId: 'm5', fecha: '2026-09-08', horas: 1.5, concepto: 'Gestión con fedatario núm. 42', facturable: true },
  { id: 'r4', casoId: 'k3', miembroId: 'm4', fecha: '2026-09-07', horas: 4, concepto: 'Preparación audiencia de juicio', facturable: true },
  { id: 'r5', casoId: 'k4', miembroId: 'm3', fecha: '2026-09-05', horas: 2.5, concepto: 'Contrato local 14 — versión 3', facturable: true },
  { id: 'r6', casoId: 'k2', miembroId: 'm3', fecha: '2026-09-04', horas: 3, concepto: 'Cuestionario pericial — primer borrador', facturable: true },
  { id: 'r7', casoId: 'k6', miembroId: 'm4', fecha: '2026-09-03', horas: 2, concepto: 'Escrito de informe justificado', facturable: true },
  { id: 'r8', casoId: 'k1', miembroId: 'm1', fecha: '2026-09-02', horas: 1, concepto: 'Memo interno SAPI bursátil vs. no bursátil', facturable: false },
]

export const NOTIFICACIONES: Notificacion[] = [
  { id: 'no1', tipo: 'plazo', texto: 'Término fatal mañana', detalle: 'Ratificación de demanda — Ernesto Belli (k3)', fecha: '2026-09-10 08:00', leida: false },
  { id: 'no2', tipo: 'compartido', texto: 'Pari Cortázar subió acta_constitutiva v2', detalle: 'Caso MRC-2026-014 · versión nueva', fecha: '2026-09-04 17:58', leida: false },
  { id: 'no3', tipo: 'nota', texto: 'Nueva nota en Alulia vs. Bento', detalle: 'Diego Salcedo — estrategia confesional', fecha: '2026-09-09 16:41', leida: false },
  { id: 'no4', tipo: 'tarea', texto: 'Tarea vencida hoy', detalle: 'Preparar cuestionario pericial — Tomás Villa', fecha: '2026-09-10 09:00', leida: true },
  { id: 'no5', tipo: 'solicitud', texto: 'Solicitud de acceso pendiente', detalle: 'Estudio Norte pide acceso a «Constitución S.A.P.I.» como asesor externo', fecha: '2026-09-07 12:20', leida: true },
]

export const miembro = (id: string) => MIEMBROS.find((m) => m.id === id)!
export const cliente = (id: string) => CLIENTES.find((c) => c.id === id)!
export const caso = (id: string) => CASOS.find((c) => c.id === id)!
