import {
  Bell,
  Briefcase,
  CalendarClock,
  Clock3,
  FolderKanban,
  LayoutDashboard,
  Library,
  Moon,
  Scale,
  Search,
  ShieldCheck,
  Sun,
  Users,
  Plus,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { FIRMA, USUARIO } from '@/data/mock'
import { Avatar, Kbd } from '@/components/bits'
import type { Page } from '@/App'

const NAV: { id: Page; label: string; icon: any; hint?: string }[] = [
  { id: 'panel', label: 'Panel', icon: LayoutDashboard },
  { id: 'casos', label: 'Casos', icon: FolderKanban },
  { id: 'clientes', label: 'Clientes', icon: Users },
  { id: 'biblioteca', label: 'Biblioteca', icon: Library },
  { id: 'agenda', label: 'Agenda y plazos', icon: CalendarClock },
  { id: 'tiempo', label: 'Tiempo y honorarios', icon: Clock3 },
]

const NAV_OPS: { id: Page; label: string; icon: any }[] = [
  { id: 'conflictos', label: 'Verificación de conflictos', icon: ShieldCheck },
]

export function Sidebar({ page, onNavigate }: { page: Page; onNavigate: (p: Page) => void }) {
  return (
    <aside className="flex h-full w-[248px] shrink-0 flex-col border-r border-sidebar-border bg-sidebar-background">
      {/* marca */}
      <div className="flex items-center gap-2.5 border-b border-sidebar-border px-5 py-4">
        <span className="flex size-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
          <Scale className="size-4" />
        </span>
        <div className="min-w-0">
          <p className="font-display text-[15px] font-semibold leading-tight tracking-tight">
            AI Justicia
          </p>
          <p className="truncate font-mono2 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
            {FIRMA.nombre}
          </p>
        </div>
      </div>

      <nav className="flex-1 space-y-6 overflow-y-auto px-3 py-4">
        <div>
          <p className="mb-1.5 px-2 font-mono2 text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
            Trabajo
          </p>
          {NAV.map((item) => (
            <NavItem
              key={item.id}
              active={page === item.id}
              onClick={() => onNavigate(item.id)}
              icon={<item.icon className="size-4" />}
              label={item.label}
            />
          ))}
        </div>
        <div>
          <p className="mb-1.5 px-2 font-mono2 text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
            Cumplimiento
          </p>
          {NAV_OPS.map((item) => (
            <NavItem
              key={item.id}
              active={page === item.id}
              onClick={() => onNavigate(item.id)}
              icon={<item.icon className="size-4" />}
              label={item.label}
            />
          ))}
        </div>
      </nav>

      {/* usuario */}
      <div className="border-t border-sidebar-border p-3">
        <button
          onClick={() => onNavigate('ajustes')}
          className={cn(
            'flex w-full items-center gap-2.5 rounded-md px-2 py-2 text-left transition-colors hover:bg-sidebar-accent',
            page === 'ajustes' && 'bg-sidebar-accent'
          )}
        >
          <Avatar iniciales={USUARIO.iniciales} />
          <div className="min-w-0">
            <p className="truncate text-[13px] font-medium">{USUARIO.nombre}</p>
            <p className="font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">
              {USUARIO.rol} · Ajustes
            </p>
          </div>
        </button>
      </div>
    </aside>
  )
}

function NavItem({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean
  onClick: () => void
  icon: React.ReactNode
  label: string
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'group flex w-full items-center gap-2.5 rounded-md px-2 py-1.5 text-[13.5px] transition-colors duration-200',
        active
          ? 'bg-sidebar-accent font-medium text-sidebar-accent-foreground'
          : 'text-sidebar-foreground/80 hover:bg-sidebar-accent/60 hover:text-sidebar-foreground'
      )}
    >
      <span className={cn(active ? 'text-primary' : 'text-muted-foreground group-hover:text-foreground')}>
        {icon}
      </span>
      {label}
      {active && <span className="ml-auto h-4 w-0.5 rounded-full bg-primary" />}
    </button>
  )
}

export function Topbar({
  title,
  subtitle,
  unread,
  dark,
  onToggleDark,
  onOpenSearch,
  onOpenNotifications,
  onNewCase,
}: {
  title: string
  subtitle?: string
  unread: number
  dark: boolean
  onToggleDark: () => void
  onOpenSearch: () => void
  onOpenNotifications: () => void
  onNewCase: () => void
}) {
  return (
    <header className="flex h-14 shrink-0 items-center gap-3 border-b border-border bg-background/80 px-5 backdrop-blur">
      <div className="min-w-0 flex-1">
        <h1 className="font-display text-lg font-semibold leading-tight tracking-tight">{title}</h1>
        {subtitle && (
          <p className="truncate font-mono2 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
            {subtitle}
          </p>
        )}
      </div>

      <button
        onClick={onOpenSearch}
        className="flex h-8 w-64 items-center gap-2 rounded-md border border-input bg-card px-3 text-[13px] text-muted-foreground shadow-sm transition-colors hover:border-primary/40 hover:text-foreground"
      >
        <Search className="size-3.5" />
        <span className="flex-1 text-left">Buscar casos, clientes, documentos…</span>
        <Kbd>⌘K</Kbd>
      </button>

      <button
        onClick={onNewCase}
        className="flex h-8 items-center gap-1.5 rounded-md bg-primary px-3 text-[13px] font-medium text-primary-foreground shadow-sm transition-colors hover:bg-primary/90"
      >
        <Plus className="size-4" /> Nuevo caso
      </button>

      <button
        onClick={onToggleDark}
        className="flex size-8 items-center justify-center rounded-md border border-input bg-card text-muted-foreground shadow-sm transition-colors hover:text-foreground"
        aria-label="Cambiar tema"
      >
        {dark ? <Sun className="size-4" /> : <Moon className="size-4" />}
      </button>

      <button
        onClick={onOpenNotifications}
        className="relative flex size-8 items-center justify-center rounded-md border border-input bg-card text-muted-foreground shadow-sm transition-colors hover:text-foreground"
        aria-label="Notificaciones"
      >
        <Bell className="size-4" />
        {unread > 0 && (
          <span className="absolute -right-1 -top-1 flex size-4 items-center justify-center rounded-full bg-oxblood font-mono2 text-[9px] font-medium text-white">
            {unread}
          </span>
        )}
      </button>
    </header>
  )
}

export { Briefcase }
