import { useEffect, useMemo, useState } from 'react'
import { Bell, CalendarClock, FileText, FolderKanban, Library, MessageSquarePlus, ScrollText, ShieldAlert, Users } from 'lucide-react'
import { Dialog, DialogContent } from '@/components/ui/dialog'
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { CASOS, CLIENTES, MEMOS, NOTIFICACIONES, PLANTILLAS, caso } from '@/data/mock'
import { MateriaBadge } from '@/components/bits'
import { cn } from '@/lib/utils'

/* ---------------- Command palette (⌘K) ---------------- */

type Resultado = {
  grupo: string
  icon: React.ReactNode
  titulo: string
  detalle: string
  accion: () => void
}

export function CommandPalette({
  open,
  onClose,
  goCaso,
  goCliente,
  goBiblioteca,
}: {
  open: boolean
  onClose: () => void
  goCaso: (id: string) => void
  goCliente: (id: string) => void
  goBiblioteca: (tab: 'plantillas' | 'memos') => void
}) {
  const [q, setQ] = useState('')

  useEffect(() => {
    if (open) setQ('')
  }, [open])

  const resultados = useMemo<Resultado[]>(() => {
    const t = q.trim().toLowerCase()
    const match = (...s: (string | undefined)[]) => !t || s.some((x) => x?.toLowerCase().includes(t))
    const out: Resultado[] = []
    CASOS.filter((c) => match(c.nombre, c.folio, c.materia, c.expedienteJudicial)).forEach((c) =>
      out.push({
        grupo: 'Casos',
        icon: <FolderKanban className="size-4" />,
        titulo: c.nombre,
        detalle: `${c.folio} · ${c.materia}`,
        accion: () => goCaso(c.id),
      })
    )
    CLIENTES.filter((c) => match(c.nombre, c.email)).forEach((c) =>
      out.push({
        grupo: 'Clientes',
        icon: <Users className="size-4" />,
        titulo: c.nombre,
        detalle: c.tipo,
        accion: () => goCliente(c.id),
      })
    )
    PLANTILLAS.filter((p) => match(p.nombre, p.materia)).forEach((p) =>
      out.push({
        grupo: 'Plantillas',
        icon: <ScrollText className="size-4" />,
        titulo: p.nombre,
        detalle: `${p.materia} · v${p.version}`,
        accion: () => goBiblioteca('plantillas'),
      })
    )
    MEMOS.filter((m) => match(m.titulo, m.tags.join(' '))).forEach((m) =>
      out.push({
        grupo: 'Memos',
        icon: <FileText className="size-4" />,
        titulo: m.titulo,
        detalle: `${m.autor} · ${m.fecha}`,
        accion: () => goBiblioteca('memos'),
      })
    )
    return out
  }, [q, goCaso, goCliente, goBiblioteca])

  const grupos = [...new Set(resultados.map((r) => r.grupo))]

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="top-[18%] max-w-xl translate-y-0 gap-0 overflow-hidden p-0">
        <div className="flex items-center gap-2 border-b border-border px-4">
          <Library className="size-4 text-muted-foreground" />
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar en todo el despacho…"
            className="h-12 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
          />
          <kbd className="rounded border border-border bg-muted px-1.5 font-mono2 text-[10px] text-muted-foreground">esc</kbd>
        </div>
        <div className="max-h-[340px] overflow-y-auto p-2">
          {resultados.length === 0 && (
            <p className="px-3 py-8 text-center text-sm text-muted-foreground">
              Sin resultados para «{q}»
            </p>
          )}
          {grupos.map((g) => (
            <div key={g} className="mb-1">
              <p className="px-3 py-1.5 font-mono2 text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
                {g}
              </p>
              {resultados
                .filter((r) => r.grupo === g)
                .map((r, i) => (
                  <button
                    key={g + i}
                    onClick={() => {
                      r.accion()
                      onClose()
                    }}
                    className="flex w-full items-center gap-3 rounded-md px-3 py-2 text-left transition-colors hover:bg-accent"
                  >
                    <span className="text-muted-foreground">{r.icon}</span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[13.5px]">{r.titulo}</span>
                      <span className="block truncate text-xs text-muted-foreground">{r.detalle}</span>
                    </span>
                  </button>
                ))}
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  )
}

/* ---------------- Notifications drawer ---------------- */

const TIPO_ICON: Record<string, any> = {
  plazo: CalendarClock,
  compartido: FolderKanban,
  nota: MessageSquarePlus,
  tarea: ShieldAlert,
  solicitud: Users,
}

export function NotificationsSheet({
  open,
  onClose,
  goCaso,
}: {
  open: boolean
  onClose: () => void
  goCaso: (id: string) => void
}) {
  const [items, setItems] = useState(NOTIFICACIONES)

  return (
    <Sheet open={open} onOpenChange={(v) => !v && onClose()}>
      <SheetContent className="w-[380px] p-0">
        <SheetHeader className="border-b border-border px-5 py-4">
          <SheetTitle className="font-display text-lg">Notificaciones</SheetTitle>
          <button
            onClick={() => setItems(items.map((i) => ({ ...i, leida: true })))}
            className="text-xs text-primary hover:underline"
          >
            Marcar todas como leídas
          </button>
        </SheetHeader>
        <div className="divide-y divide-border">
          {items.map((n) => {
            const Icon = TIPO_ICON[n.tipo] ?? Bell
            const casoId = n.detalle.match(/k\d/)?.[0]
            return (
              <button
                key={n.id}
                onClick={() => {
                  setItems(items.map((i) => (i.id === n.id ? { ...i, leida: true } : i)))
                  if (casoId && caso(casoId)) {
                    goCaso(casoId)
                    onClose()
                  }
                }}
                className={cn(
                  'flex w-full gap-3 px-5 py-3.5 text-left transition-colors hover:bg-accent/60',
                  !n.leida && 'bg-primary/[0.04]'
                )}
              >
                <span className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground">
                  <Icon className="size-4" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-2">
                    <span className={cn('text-[13.5px]', !n.leida && 'font-semibold')}>{n.texto}</span>
                    {!n.leida && <span className="size-1.5 shrink-0 rounded-full bg-primary" />}
                  </span>
                  <span className="mt-0.5 block text-xs leading-relaxed text-muted-foreground">{n.detalle}</span>
                  <span className="mt-1 block font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground/70">
                    {n.fecha}
                  </span>
                </span>
              </button>
            )
          })}
        </div>
      </SheetContent>
    </Sheet>
  )
}

/* helpers de búsqueda global que usan MateriaBadge */
export { MateriaBadge }
