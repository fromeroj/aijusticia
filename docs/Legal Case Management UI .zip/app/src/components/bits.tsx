import { cn } from '@/lib/utils'
import type { EstadoCaso, Materia } from '@/types'

const MATERIA_STYLES: Record<string, string> = {
  General: 'bg-muted text-muted-foreground border-border',
  Mercantil: 'bg-[hsl(var(--gold)/0.12)] text-gold border-[hsl(var(--gold)/0.3)]',
  Civil: 'bg-[hsl(var(--sage)/0.12)] text-sage border-[hsl(var(--sage)/0.3)]',
  Laboral: 'bg-[hsl(var(--primary)/0.1)] text-primary border-[hsl(var(--primary)/0.3)]',
  Familiar: 'bg-purple-500/10 text-purple-700 dark:text-purple-300 border-purple-500/25',
  Penal: 'bg-[hsl(var(--oxblood)/0.1)] text-oxblood border-[hsl(var(--oxblood)/0.3)]',
  Amparo: 'bg-sky-500/10 text-sky-700 dark:text-sky-300 border-sky-500/25',
  Administrativo: 'bg-teal-500/10 text-teal-700 dark:text-teal-300 border-teal-500/25',
  Fiscal: 'bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/25',
}

export function MateriaBadge({ materia, className }: { materia: Materia | string; className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium tracking-wide',
        MATERIA_STYLES[materia] ?? MATERIA_STYLES.General,
        className
      )}
    >
      {materia}
    </span>
  )
}

const ESTADO_STYLES: Record<EstadoCaso, string> = {
  Activo: 'text-sage',
  'En espera': 'text-gold',
  Suspendido: 'text-oxblood',
  Concluido: 'text-muted-foreground',
  Archivado: 'text-muted-foreground',
}

export function EstadoDot({ estado }: { estado: EstadoCaso }) {
  return (
    <span className={cn('inline-flex items-center gap-1.5 text-xs', ESTADO_STYLES[estado])}>
      <span className="size-1.5 rounded-full bg-current" />
      {estado}
    </span>
  )
}

export function Avatar({ iniciales, className }: { iniciales: string; className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex size-7 shrink-0 items-center justify-center rounded-full bg-primary/10 font-mono2 text-[10px] font-medium text-primary ring-1 ring-primary/25',
        className
      )}
    >
      {iniciales}
    </span>
  )
}

export function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="font-mono2 text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
      {children}
    </p>
  )
}

export function Kbd({ children }: { children: React.ReactNode }) {
  return (
    <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border border-border bg-muted px-1.5 font-mono2 text-[10px] font-medium text-muted-foreground">
      {children}
    </kbd>
  )
}

export function fmtFecha(iso: string) {
  const [y, m, d] = iso.split('T')[0].split('-').map(Number)
  const meses = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic']
  return `${d} ${meses[m - 1]} ${y}`
}

export function diasHasta(iso: string) {
  const hoy = new Date('2026-09-10T00:00:00')
  const fecha = new Date(iso + 'T00:00:00')
  return Math.round((fecha.getTime() - hoy.getTime()) / 86400000)
}

export function fmtDinero(n: number) {
  return '$' + n.toLocaleString('es-MX') + ' MXN'
}
