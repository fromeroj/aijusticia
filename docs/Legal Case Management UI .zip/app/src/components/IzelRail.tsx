import { useEffect, useRef, useState } from 'react'
import { Paperclip, Send, Sparkles, Square } from 'lucide-react'
import type { Caso } from '@/types'
import { cn } from '@/lib/utils'

interface Msg {
  rol: 'user' | 'izel'
  texto: string
  citas?: string[]
}

const RESPUESTAS: Record<string, { texto: string; citas?: string[] }> = {
  default: {
    texto:
      'Con base en el expediente del caso activo, esto es lo relevante: los documentos con OCR ya están indexados, así que puedo citarlos directamente. Si necesitas un criterio específico, indícame la materia y la jurisdicción para acotar la búsqueda en el corpus verificado.',
    citas: ['LGSM art. 112', 'Código Civil CDMX art. 2396'],
  },
  sapi: {
    texto:
      'Sobre la SAPI: la diferencia práctica entre bursátil y no bursátil no es cotizar en bolsa, sino el régimen de admisión de accionistas y la supresión del derecho de preferencia. Para Estudio Norte recomiendo mantener la serie «B» no bursátil con remisión expresa al pacto de socios, como ya acordaron en la nota del 6 de septiembre.',
    citas: ['LGSM arts. 112, 116 y 210-Bis', 'Pacto de socios Estudio Norte (v2, cláusula 4ª)'],
  },
  plazo: {
    texto:
      'Revisé los plazos del despacho: el término más próximo es la ratificación de demanda de Ernesto Belli, que vence mañana 11 de septiembre y es fatal. Después sigue la confesional del representante de Bento el 14 de septiembre. ¿Quieres que prepare un borrador de escrito para alguno?',
  },
}

function pickRespuesta(q: string, c?: Caso | null) {
  const t = q.toLowerCase()
  if (t.includes('sapi') || t.includes('serie') || t.includes('bursátil')) return RESPUESTAS.sapi
  if (t.includes('plazo') || t.includes('vence') || t.includes('término')) return RESPUESTAS.plazo
  const base = RESPUESTAS.default
  if (c) {
    return {
      ...base,
      texto: `Contexto activo: «${c.nombre}» (${c.folio}, ${c.materia}, etapa: ${c.etapa}). ` + base.texto,
    }
  }
  return base
}

export function IzelRail({ casoActivo }: { casoActivo?: Caso | null }) {
  const [msgs, setMsgs] = useState<Msg[]>([])
  const [input, setInput] = useState('')
  const [escribiendo, setEscribiendo] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [msgs, escribiendo])

  const enviar = () => {
    const q = input.trim()
    if (!q || escribiendo) return
    setMsgs((m) => [...m, { rol: 'user', texto: q }])
    setInput('')
    setEscribiendo(true)
    const r = pickRespuesta(q, casoActivo)
    // streaming simulado: placeholder que se va llenando
    setMsgs((m) => [...m, { rol: 'izel', texto: '' }])
    let i = 0
    const texto = r.texto
    const timer = setInterval(() => {
      i += 6
      const parcial = texto.slice(0, i)
      setMsgs((m) => {
        const copia = [...m]
        copia[copia.length - 1] = { rol: 'izel', texto: parcial }
        return copia
      })
      if (i >= texto.length) {
        clearInterval(timer)
        setMsgs((m) => {
          const copia = [...m]
          copia[copia.length - 1] = { rol: 'izel', texto, citas: r.citas }
          return copia
        })
        setEscribiendo(false)
      }
    }, 24)
  }

  return (
    <div className="flex h-full w-[330px] shrink-0 flex-col border-l border-border bg-card/60">
      <div className="flex items-center gap-2 border-b border-border px-4 py-3">
        <span className="flex size-7 items-center justify-center rounded-full bg-primary/10 text-primary ring-1 ring-primary/25">
          <Sparkles className="size-3.5" />
        </span>
        <div className="flex-1">
          <p className="font-display text-[14px] font-semibold leading-tight">Izel</p>
          <p className="font-mono2 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
            {casoActivo ? `Contexto: ${casoActivo.folio}` : 'Consulta jurídica'}
          </p>
        </div>
        <span className="flex items-center gap-1.5 font-mono2 text-[10px] uppercase tracking-wider text-sage">
          <span className="size-1.5 rounded-full bg-sage" /> en línea
        </span>
      </div>

      <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto px-4 py-4">
        {msgs.length === 0 && (
          <div className="pt-8 text-center">
            <p className="font-display text-xl font-medium tracking-tight">Hola, soy Izel</p>
            <p className="mx-auto mt-2 max-w-[240px] text-xs leading-relaxed text-muted-foreground">
              {casoActivo
                ? `Tengo el contexto de «${casoActivo.nombre}»: expediente, ${casoActivo.documentos.length} documentos y ${casoActivo.notas.length} notas.`
                : 'Selecciona un caso y preguntaré con su contexto completo.'}
            </p>
            <div className="mx-auto mt-5 flex max-w-[260px] flex-col gap-1.5">
              {['¿Qué diferencia hay entre SAPI bursátil y no bursátil?', '¿Qué plazos vencen esta semana?', 'Resume el estado del caso'].map((s) => (
                <button
                  key={s}
                  onClick={() => setInput(s)}
                  className="rounded-md border border-border bg-background px-3 py-2 text-left text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}
        {msgs.map((m, i) => (
          <div key={i} className={cn('flex', m.rol === 'user' ? 'justify-end' : 'justify-start')}>
            <div
              className={cn(
                'max-w-[88%] rounded-lg px-3 py-2 text-[13px] leading-relaxed',
                m.rol === 'user'
                  ? 'bg-primary text-primary-foreground'
                  : 'border border-border bg-background'
              )}
            >
              {m.texto}
              {m.citas && (
                <div className="mt-2 space-y-1 border-t border-border/60 pt-2">
                  {m.citas.map((c) => (
                    <p key={c} className="font-mono2 text-[10px] text-muted-foreground">
                      ◦ {c}
                    </p>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
        {escribiendo && msgs[msgs.length - 1]?.texto === '' && (
          <p className="font-mono2 text-[10px] uppercase tracking-wider text-muted-foreground">Izel está redactando…</p>
        )}
      </div>

      <div className="border-t border-border p-3">
        <div className="flex items-end gap-2 rounded-md border border-input bg-background px-2 py-1.5 focus-within:border-primary/50">
          <button className="flex size-7 items-center justify-center rounded text-muted-foreground transition-colors hover:text-foreground" title="Adjuntar documento">
            <Paperclip className="size-4" />
          </button>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault()
                enviar()
              }
            }}
            rows={2}
            placeholder="Preguntar a Izel…"
            className="flex-1 resize-none bg-transparent text-[13px] outline-none placeholder:text-muted-foreground"
          />
          <button
            onClick={enviar}
            className="flex size-7 items-center justify-center rounded bg-primary text-primary-foreground transition-colors hover:bg-primary/90"
          >
            {escribiendo ? <Square className="size-3" /> : <Send className="size-3.5" />}
          </button>
        </div>
        <p className="mt-2 text-center font-mono2 text-[9px] uppercase tracking-wider text-muted-foreground/70">
          Información jurídica general · no sustituye asesoría profesional
        </p>
      </div>
    </div>
  )
}
